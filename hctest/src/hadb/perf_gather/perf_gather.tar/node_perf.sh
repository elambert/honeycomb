#!/bin/bash

iostat -T d -l 4 -xnd c0d0 5 >> disk_data &
vmstat 5 >> vmstat_data &
mpstat 5 >> mpstat_data &
while ((1))
do
uptime >> cpu_data
sleep 5
done

