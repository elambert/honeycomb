#!/bin/bash

n=0
while (( $n < 16 ))
do
	node=`printf "hcb1%02d" $[$n+1]`
	ssh -t $node 'java -Djava.library.path=/opt/honeycomb/lib -jar mdLoad.jar $n >> md_data' &
        ssh -t $node './node_perf.sh' &
        n=$[$n+1]
	echo "Node $node started"
done
./cheat_perf.pl >> ops_data &
echo "Test running.  To monitor: tail -f /tmp/ops_data"
echo "To stop: ./stop_test.pl"
echo "To gather data: ./collect_data.sh"
