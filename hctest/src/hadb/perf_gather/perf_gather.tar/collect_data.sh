#!/bin/bash


rm -rf perf_gather_dataset

mkdir perf_gather_dataset
SSHARGS="-q -o StrictHostKeyChecking=no"
n=0
while (( $n < 16 ))
do
        node=`printf "hcb1%02d" $[$n+1]`
        scp $SSHARGS $node:md_data perf_gather_dataset/md_data-$node
        scp $SSHARGS $node:disk_data perf_gather_dataset/disk_data-$node
        scp $SSHARGS $node:vmstat_data perf_gather_dataset/vmstat_data-$node
        scp $SSHARGS $node:mpstat_data perf_gather_dataset/mpstat_data-$node
        scp $SSHARGS $node:cpu_data perf_gather_dataset/cpu_data-$node
        scp $SSHARGS $node:/data/0/hadb/history/\* perf_gather_dataset
        n=$[$n+1]
	echo "Data collected from $node"
done
cp ops_data perf_gather_dataset
rm -f perf_gather_data_dataset.tar
tar cvf perf_gather_dataset.tar perf_gather_dataset

