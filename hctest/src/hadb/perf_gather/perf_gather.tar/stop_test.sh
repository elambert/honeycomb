#!/bin/bash

n=0
while (( $n < 16 ))
do
	node=`printf "hcb1%02d" $[$n+1]`
        ssh -t $node 'pkill -f node_perf.sh\ ;pkill -f iostat\ ;pkill -f vmstat\ ;pkill -f mpstat\ ;pkill -f mdLoad'
        n=$[$n+1]
	echo "Node $node stopped"
done
pkill -f cheat_perf.pl
