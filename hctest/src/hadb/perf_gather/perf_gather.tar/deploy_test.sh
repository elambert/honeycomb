#!/bin/bash
SSHARGS="-q -o StrictHostKeyChecking=no"
n=0
while (( $n < 16 ))
do
	node=`printf "hcb1%02d" $[$n+1]`
        scp $SSHARGS mdLoad.jar $node:
        scp $SSHARGS node_perf.sh $node:
        n=$[$n+1]
	echo "Node $node initialized"
done

