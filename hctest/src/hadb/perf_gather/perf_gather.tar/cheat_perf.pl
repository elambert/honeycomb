#!/usr/bin/perl

$TIME_TO_SLEEP = 10;

sub getCount() {
  #my @output = `echo 'select count(*) from T98C20F;' | ssh hcb101 /opt/SUNWhadb/4/bin/clusql localhost:15005 system+superduper 2>/dev/null`;
  #my @fields = split(/ /, $output[0]);
  #chomp($output[3]);
  #$output[3]=~s/[ ]*([^ ]+)/\1/;
  #return($output[3]);
  return(0);
}

sub getSize() {
  my @output = `ssh hcb101 'echo "admin" | /opt/SUNWhadb/4/bin/hadbm deviceinfo honeycomb`;
  my $result = 0;

  for (my $i=1; $i<@output; $i++) {
    my (@fields) = split(/[ ]+/, $output[$i]);
    $result += $fields[1]-$fields[2];
  }

  return($result);
}

$prev = getCount();
$starttime = time();
$iter = 1;

while (1) {
  sleep ($TIME_TO_SLEEP*$iter+$starttime-time());
  $current = getCount();
  $perf = ($current-$prev)/$TIME_TO_SLEEP;
  print (($iter*$TIME_TO_SLEEP)."\t$current\t$perf\t".getSize()."\n");
  $prev = $current;
  $iter++;
}
