package SQLite;

import SQLite.*;
import java.io.*;
import java.util.*;

/**
 * SQLite command line shell. This is a partial reimplementaion
 * of sqlite/src/shell.c and can be invoked by:<P>
 *
 * <verb>
 *     java SQLite.Shell [OPTIONS] database [SHELLCMD]
 * </verb>
 */

public class Shell implements Callback {
    Database db;
    boolean echo;
    int count;
    int mode;
    boolean showHeader;
    String tableName;
    String sep;
    String cols[];
    int colwidth[];
    String destTable;

    static final int MODE_Line = 0;
    static final int MODE_Column = 1;
    static final int MODE_List = 2;
    static final int MODE_Semi = 3;
    static final int MODE_Html = 4;
    static final int MODE_Insert = 5;

    protected Object clone() {
        Shell s = new Shell();
	s.db = db;
	s.echo = echo;
	s.mode = mode;
	s.count = 0;
	s.showHeader = showHeader;
	s.tableName = tableName;
	s.sep = sep;
	s.colwidth = colwidth;
	return s;
    }

    static public String sql_quote(String str) {
	if (str == null) {
	    return "NULL";
	}
	int i, single = 0, dbl = 0;
	for (i = 0; i < str.length(); i++) {
	    if (str.charAt(i) == '\'') {
		single++;
	    } else if (str.charAt(i) == '"') {
		dbl++;
	    }
	}
	if (single == 0) {
	    return "'" + str + "'";
	}
	if (dbl == 0) {
	    return "\"" + str + "\"";
	}
	StringBuffer sb = new StringBuffer("'");
	for (i = 0; i < str.length(); i++) {
	    char c = str.charAt(i);
	    if (c == '\'') {
		sb.append("''");
	    } else {
		sb.append(c);
	    }
	}
	return sb.toString();
    }

    static String html_quote(String str) {
	if (str == null) {
	    return "NULL";
	}
	StringBuffer sb = new StringBuffer();
	for (int i = 0; i < str.length(); i++) {
	    char c = str.charAt(i);
	    if (c == '<') {
		sb.append("&lt;");
	    } else if (c == '>') {
		sb.append("&gt;");
	    } else if (c == '&') {
		sb.append("&amp;");
	    } else {
		sb.append(c);
	    }
	}
	return sb.toString();
    }

    static boolean is_numeric(String str) {
	try {
	    Double d = Double.valueOf(str);
	} catch (java.lang.Exception e) {
	    return false;
	}
	return true;
    }

    void set_table_name(String str) {
	if (str == null) {
	    tableName = "";
	    return;
	}
	tableName = Shell.sql_quote(str);
    }

    public void columns(String args[]) {
	cols = args;
    }

    public void types(String args[]) {
	/* Empty body to satisfy SQLite.Callback interface. */
    }

    public boolean newrow(String args[]) {
	int i;
	switch (mode) {
	case Shell.MODE_Line:
	    if (args.length == 0) {
		break;
	    }
	    if (count++ > 0) {
		System.out.println("");
	    }
	    for (i = 0; i < args.length; i++) {
		System.out.println(cols[i] + " = " +
				   args[i] == null ? "NULL" : args[i]);
	    }
	    break;
	case Shell.MODE_Column:
	    String csep = "";
	    if (count++ == 0) {
		colwidth = new int[args.length];
		for (i = 0; i < args.length; i++) {
		    int w, n;
		    w = cols[i].length();
		    if (w < 10) {
			w = 10;
		    }
		    colwidth[i] = w;
		    if (showHeader) {
			System.out.print(csep + cols[i]);
			csep = " ";
		    }
		}
		if (showHeader) {
		    System.out.println("");
		}
	    }
	    if (args.length == 0) {
		break;
	    }
	    csep = "";
	    for (i = 0; i < args.length; i++) {
		System.out.print(csep + (args[i] == null ? "NULL" : args[i]));
		csep = " ";
	    }
	    System.out.println("");
	    break;
	case Shell.MODE_Semi:
	case Shell.MODE_List:
	    if (count++ == 0 && showHeader) {
		for (i = 0; i < args.length; i++) {
		    System.out.print(cols[i] +
				     (i == args.length - 1 ? "\n" : sep));
		}
	    }
	    if (args.length == 0) {
		break;
	    }
	    for (i = 0; i < args.length; i++) {
		System.out.print(args[i] == null ? "NULL" : args[i]);
		if (mode == Shell.MODE_Semi) {
		    System.out.print(";");
		} else if (i < args.length - 1) {
		    System.out.print(sep);
		}
	    }
	    System.out.println("");
	    break;
	case MODE_Html:
	    if (count++ == 0 && showHeader) {
		System.out.print("<TR>");
		for (i = 0; i < args.length; i++) {
		    System.out.print("<TH>" + html_quote(cols[i]) + "</TH>");
		}
		System.out.println("</TR>");
	    }
	    if (args.length == 0) {
		break;
	    }
	    System.out.print("<TR>");
	    for (i = 0; i < args.length; i++) {
		System.out.print("<TD>" + html_quote(args[i]) + "</TD>");
	    }
	    System.out.println("</TR>");
	    break;
	case MODE_Insert:
	    if (args.length == 0) {
		break;
	    }
	    String tname = tableName;
	    if (destTable != null) {
	        tname = destTable;
	    }
	    System.out.print("INSERT INTO " + tname + " VALUES(");
	    for (i = 0; i < args.length; i++) {
	        String tsep = i > 0 ? "," : "";
		if (args[i] == null) {
		    System.out.print(tsep + "NULL");
		} else if (is_numeric(args[i])) {
		    System.out.print(tsep + args[i]);
		} else {
		    System.out.print(tsep + sql_quote(args[i]));
		}
	    }
	    System.out.println(");");
	    break;
	}
	return false;
    }

    void do_meta(String line) {
        StringTokenizer st = new StringTokenizer(line.toLowerCase());
	int n = st.countTokens();
	if (n <= 0) {
	    return;
	}
	String cmd = st.nextToken();
	String args[] = new String[n - 1];
	int i = 0;
	while (st.hasMoreTokens()) {
	    args[i] = st.nextToken();
	    ++i;
	}
	if (cmd.compareTo(".dump") == 0) {
	    new DBDump(this, args);
	    return;
	}
	if (cmd.compareTo(".echo") == 0) {
	    if (args.length > 0 &&
		(args[0].startsWith("y") || args[0].startsWith("on"))) {
		echo = true;
	    }
	    return;
	}
	if (cmd.compareTo(".exit") == 0) {
	    try {
		db.close();
	    } catch (Exception e) {
	    }
	    System.exit(0);
	}
	if (cmd.compareTo(".header") == 0) {
	    if (args.length > 0 &&
		(args[0].startsWith("y") || args[0].startsWith("on"))) {
		showHeader = true;
	    }
	    return;
	}
	if (cmd.compareTo(".help") == 0) {
	    System.out.println(".dump ?TABLE? ...  Dump database in text fmt");
	    System.out.println(".echo ON|OFF       Command echo on or off");
	    System.out.println(".enc ?NAME?        Change encoding");
	    System.out.println(".exit              Exit program");
	    System.out.println(".header ON|OFF     Display headers on or off");
	    System.out.println(".help              This message");
	    System.out.println(".mode MODE         Set output mode to\n" +
			       "                   line, column, insert\n" +
			       "                   list, or html");
	    System.out.println(".mode insert TABLE Generate SQL insert stmts");
	    System.out.println(".schema ?PATTERN?  List table schema");
	    System.out.println(".separator STRING  Set separator string");
	    System.out.println(".tables ?PATTERN?  List table names");
	    return;
	}
	if (cmd.compareTo(".mode") == 0) {
	    if (args.length > 0) {
		if (args[0].compareTo("line") == 0) {
		    mode = Shell.MODE_Line;
		} else if (args[0].compareTo("column") == 0) {
		    mode = Shell.MODE_Column;
		} else if (args[0].compareTo("list") == 0) {
		    mode = Shell.MODE_List;
		} else if (args[0].compareTo("html") == 0) {
		    mode = Shell.MODE_Html;
		} else if (args[0].compareTo("insert") == 0) {
		    mode = Shell.MODE_Html;
		    if (args.length > 1) {
			destTable = args[1];
		    }
		}
	    }
	    return;
	}
	if (cmd.compareTo(".separator") == 0) {
	    if (args.length > 0) {
		sep = args[0];
	    }
	    return;
	}
	if (cmd.compareTo(".tables") == 0) {
	    TableResult t = null;
	    if (args.length > 0) {
		try {
		    String qarg[] = new String[1];
		    qarg[0] = args[0];
		    t = db.get_table("SELECT name FROM sqlite_master " +
				     "WHERE type='table' AND " +
				     "name LIKE '%%%q%%' " +
				     "ORDER BY name", qarg);
		} catch (Exception e) {
		    System.err.println("SQL Error: " + e);
		}
	    } else {
		try {
		    t = db.get_table("SELECT name FROM sqlite_master " +
				     "WHERE type='table' ORDER BY name");
		} catch (Exception e) {
		    System.err.println("SQL Error: " + e);
		}
	    }
	    if (t != null) {
		for (i = 0; i < t.nrows; i++) {
		    String tab = ((String[]) t.rows.elementAt(i))[0];
		    if (tab != null) {
			System.out.println(tab);
		    }
		}
	    }
	    return;
	}
	if (cmd.compareTo(".schema") == 0) {
	    if (args.length > 0) {
		try {
		    String qarg[] = new String[1];
		    qarg[0] = args[0];
		    db.exec("SELECT sql FROM sqlite_master " +
			    "WHERE type!='meta' AND " +
			    "name LIKE '%%%q%%' AND " +
			    "sql NOTNULL " +
			    "ORDER BY type DESC, name",
			    this, qarg);
		} catch (Exception e) {
		    System.err.println("SQL Error: " + e);
		}
	    } else {
		try {
		    db.exec("SELECT sql FROM sqlite_master " +
			    "WHERE type!='meta' AND " +
			    "sql NOTNULL " +
			    "ORDER BY tbl_name, type DESC, name",
			    this);
		} catch (Exception e) {
		    System.err.println("SQL Error: " + e);
		}
	    }
	    return;
	}
	if (cmd.compareTo(".enc") == 0) {
	    try {
		db.set_encoding(args.length > 0 ? args[0] : null);
	    } catch (Exception e) {
		System.err.println("" + e);
	    }
	    return;
	}
	System.err.println("Unknown command '" + cmd + "'");
    }

    static String read_line(BufferedReader is, String prompt) {
	try {
	    System.out.print(prompt);
	    String line = is.readLine();
	    return line;
	} catch (IOException e) {
	    return null;
	}
    }

    void do_input(BufferedReader is) {
	String line, sql = null;
	String prompt = "SQLITE> ";
	while ((line = Shell.read_line(is, prompt)) != null) {
	    if (echo) {
		System.out.println(line);
	    }
	    if (line.length() > 0 && line.charAt(0) == '.') {
	        do_meta(line);
	    } else {
		if (sql == null) {
		    sql = line;
		} else {
		    sql = sql + " " + line;
		}
		if (Database.complete(sql)) {
		    try {
			db.exec(sql, this);
		    } catch (Exception e) {
			if (!echo) {
			    System.err.println(sql);
			}
			System.err.println("SQL Error: " + e);
		    }
		    sql = null;
		    prompt = "SQLITE> ";
		} else {
		    prompt = "SQLITE? ";
		}
	    }
	}
	if (sql != null) {
	    System.err.println("Incomplete SQL: " + sql);
	}
    }

    public static void main(String args[]) {
	Shell s = new Shell();
	s.mode = Shell.MODE_List;
	s.sep = "|";
	s.showHeader = false;
	s.db = new Database();
	String dbname = null, sql = null;
	for (int i = 0; i < args.length; i++) {
	    if(args[i].compareTo("-html") ==0) {
		s.mode = Shell.MODE_Html;
	    } else if (args[i].compareTo("-list") == 0) {
		s.mode = Shell.MODE_List;
	    } else if (args[i].compareTo("-line") == 0) {
		s.mode = Shell.MODE_Line;
	    } else if (i < args.length - 1 &&
		       args[i].compareTo("-separator") == 0) {
		++i;
		s.sep = args[i];
	    } else if (args[i].compareTo("-header") == 0) {
		s.showHeader = true;
	    } else if (args[i].compareTo("-noheader") == 0) {
		s.showHeader = false;
	    } else if (args[i].compareTo("-echo") == 0) {
		s.echo = true;
	    } else if (dbname == null) {
		dbname = args[i];
	    } else if (sql == null) {
		sql = args[i];
	    } else {
		System.err.println("Arguments: ?OPTIONS? FILENAME ?SQL?");
		System.exit(1);
	    }
	}
	if (dbname == null) {
	    System.err.println("No database file given");
	    System.exit(1);
	}
	try {
	    s.db.open(dbname, 0);
	} catch (Exception e) {
	    System.err.println("Unable to open database: " + e);
	    System.exit(1);
	}
	if (sql != null) {
	    if (sql.length() > 0 && sql.charAt(0) == '.') {
	        s.do_meta(sql);
	    } else {
		try {
		    s.db.exec(sql, s);
		} catch (Exception e) {
		    System.err.println("SQL Error: " + e);
		}
	    }
	} else {
	    BufferedReader is =
		new BufferedReader(new InputStreamReader(System.in));
	    s.do_input(is);
	}
	try {
	    s.db.close();
	} catch (Exception ee) {
	}
    }
}

/**
 * Internal class for dumping an entire database.
 * It contains a special callback interface to traverse the
 * tables of the current database and output create SQL statements
 * and for the data insert SQL statements.
 */

class DBDump implements Callback {
    Shell s;

    DBDump(Shell s, String tables[]) {
        this.s = s;
	System.out.println("BEGIN TRANSACTION;");
        if (tables == null || tables.length == 0) {
	    try {
	        s.db.exec("SELECT name, type, sql FROM sqlite_master " +
			  "WHERE type!='meta' AND sql NOT NULL " +
			  "ORDER BY substr(type,2,1), name", this);
	    } catch (Exception e) {
	        System.err.println("SQL Error: " + e);
	    }
	} else {
	    String arg[] = new String[1];
	    for (int i = 0; i < tables.length; i++) {
	        arg[0] = tables[i];
		try {
		    s.db.exec("SELECT name, type, sql FROM sqlite_master " +
			      "WHERE tbl_name LIKE '%q' AND type!='meta' " +
			      " AND sql NOT NULL " +
			      " ORDER BY substr(type,2,1), name",
			      this, arg);
		} catch (Exception e) {
		    System.err.println("SQL Error: " + e);
		}
	    }
	}
	System.out.println("COMMIT;");
    }

    public void columns(String col[]) {
	/* Empty body to satisfy SQLite.Callback interface. */
    }

    public void types(String args[]) {
	/* Empty body to satisfy SQLite.Callback interface. */
    }

    public boolean newrow(String args[]) {
        if (args.length != 3) {
	    return true;
	}
	System.out.println(args[2] + ";");
	if (args[1].compareTo("table") == 0) {
	    Shell s2 = (Shell) s.clone();
	    s2.mode = Shell.MODE_Insert;
	    s2.set_table_name(args[0]);
	    String qargs[] = new String[1];
	    qargs[0] = args[0];
	    try {
	        s2.db.exec("SELECT * from '%q'", s2, qargs);
	    } catch (Exception e) {
	        System.err.println("SQL Error: " + e);
		return true;
	    }
	}
	return false;
    }
}
