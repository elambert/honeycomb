#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#if HAVE_SQLITE2
#include "sqlite.h"
#endif

#if HAVE_SQLITE3
#include "sqlite3.h"
#define HAVE_SQLITE_COMPILE 1
#define HAVE_SQLITE_PROGRESS_HANDLER 1
#define HAVE_SQLITE_TRACE 1
#endif

#if HAVE_SQLITE2 && HAVE_SQLITE3
#define HAVE_BOTH_SQLITE 1
#endif

#include "sqlite_jni.h"

/* free memory proc */

typedef void (freemem)(void *);

/* internal handle for SQLite database */

typedef struct {
    void *sqlite;		/* SQLite handle */
#if HAVE_BOTH_SQLITE
    int is3;			/* True for SQLITE3 handle */
#endif
    int ver;			/* version code */
    jobject bh;			/* BusyHandler object */
    jobject cb;			/* Callback object */
    jobject ai;			/* Authorizer object */
    jobject tr;			/* Trace object */
    jobject ph;			/* ProgressHandler object */
    JNIEnv *env;		/* Java environment for callbacks */
    int row1;			/* true while processing first row */
    int haveutf;		/* true for SQLite UTF-8 support */
    jstring enc;		/* encoding or 0 */
    struct hfunc *funcs;	/* SQLite user defined function handles */
#if HAVE_SQLITE_COMPILE
    struct hvm *vms;		/* Compiled SQLite VMs */
#endif
#if HAVE_SQLITE3
    sqlite3_stmt *stmt;		/* For callback() */
#endif
} handle;

/* internal handle for SQLite user defined function */

typedef struct hfunc {
    struct hfunc *next;		/* next function */
#if HAVE_BOTH_SQLITE
    int is3;			/* True for SQLITE3 handle */
#endif
    jobject fc;			/* FunctionContext object */
    jobject fi;			/* Function object */
    jobject db;			/* Database object */
    handle *h;			/* SQLite database handle */
    void *sf;			/* SQLite function handle */
    JNIEnv *env;		/* Java environment for callbacks */
} hfunc;

#if HAVE_SQLITE_COMPILE
/* internal handle for SQLite VM (sqlite_compile()) */

typedef struct hvm {
    struct hvm *next;		/* next vm handle */
#if HAVE_BOTH_SQLITE
    int is3;			/* True for SQLITE3 handle */
#endif
    void *vm;			/* SQLite 2/3 VM */
    char *tail;			/* tail SQL string */
    handle *h;			/* SQLite database handle */
    handle hh;			/* fake SQLite database handle */
} hvm;
#endif

/* ISO to/from UTF-8 translation */

typedef struct {
    char *result;		/* translated C string result */
    char *tofree;		/* memory to be free'd, or 0 */
    jstring jstr;		/* resulting Java string or 0 */
} transstr;

/* static cached weak class refs, field and method ids */

static jclass C_java_lang_String = 0;

static jfieldID F_SQLite_Database_handle = 0;
static jfieldID F_SQLite_Database_error_code = 0;
static jfieldID F_SQLite_FunctionContext_handle = 0;
static jfieldID F_SQLite_Vm_handle = 0;
static jfieldID F_SQLite_Vm_error_code = 0;

static jmethodID M_java_lang_String_getBytes = 0;
static jmethodID M_java_lang_String_getBytes2 = 0;
static jmethodID M_java_lang_String_initBytes = 0;
static jmethodID M_java_lang_String_initBytes2 = 0;


static void
seterr(JNIEnv *env, jobject obj, int err)
{
    jvalue v;

    v.j = 0;
    v.i = (jint) err;
    (*env)->SetIntField(env, obj, F_SQLite_Database_error_code, v.i);
}

static void
setvmerr(JNIEnv *env, jobject obj, int err)
{
    jvalue v;

    v.j = 0;
    v.i = (jint) err;
    (*env)->SetIntField(env, obj, F_SQLite_Vm_error_code, v.i);
}

static void *
common_gethandle(JNIEnv *env, jobject obj)
{
    jvalue v;

    v.j = (*env)->GetLongField(env, obj, F_SQLite_Database_handle);
    return (void *) v.l;
}

#define gethandle(env, obj) (handle *) common_gethandle(env, obj)
#if HAVE_SQLITE_COMPILE
#define gethvm(env, obj) (hvm *) common_gethandle(env, obj)
#endif

static void
delglobrefp(JNIEnv *env, jobject *obj)
{
    if (*obj) {
	(*env)->DeleteGlobalRef(env, *obj);
	*obj = 0;
    }
}

static jobject
globrefpop(JNIEnv *env, jobject *obj)
{
    jobject ret = 0;

    if (*obj) {
	ret = *obj;
	*obj = 0;
    }
    return ret;
}

static void
globrefset(JNIEnv *env, jobject obj, jobject *ref)
{
    if (ref) {
	if (obj) {	
	    *ref = (*env)->NewGlobalRef(env, obj);
	} else {
	    *ref = 0;
	}
    }
}

static void
freep(char **strp)
{
    if (strp && *strp) {
	free(*strp);
	*strp = 0;
    }
}

static void
throwex(JNIEnv *env, const char *msg)
{
    jclass except = (*env)->FindClass(env, "SQLite/Exception");

    (*env)->ExceptionClear(env);
    if (except) {
	(*env)->ThrowNew(env, except, msg);
    }
}

static void
throwoom(JNIEnv *env, const char *msg)
{
    jclass except = (*env)->FindClass(env, "java/lang/OutOfMemoryError");

    (*env)->ExceptionClear(env);
    if (except) {
	(*env)->ThrowNew(env, except, msg);
    }
}

static void
throwclosed(JNIEnv *env)
{
    throwex(env, "database already closed");
}

static void
transfree(transstr *dest)
{
    dest->result = 0;
    freep(&dest->tofree);
}

static char *
trans2iso(JNIEnv *env, int haveutf, jstring enc, jstring src,
	  transstr *dest)
{
    jbyteArray bytes = 0;
    jthrowable exc;

    dest->result = 0;
    dest->tofree = 0;
    if (haveutf) {
	const char *utf = (*env)->GetStringUTFChars(env, src, 0);

	if (!utf) {
	    return dest->result;
	}
	dest->tofree = malloc(strlen(utf) + 1);
	dest->result = dest->tofree;
	strcpy(dest->result, utf);
	(*env)->ReleaseStringUTFChars(env, src, utf);
	return dest->result;
    }
    if (enc) {
	bytes = (*env)->CallObjectMethod(env, src,
					 M_java_lang_String_getBytes2, enc);
    } else {
	bytes = (*env)->CallObjectMethod(env, src,
					 M_java_lang_String_getBytes);
    }
    exc = (*env)->ExceptionOccurred(env);
    if (!exc) {
	jint len = (*env)->GetArrayLength(env, bytes);
	dest->tofree = malloc(len + 1);
	if (!dest->tofree) {
	    throwoom(env, "string translation failed");
	    return dest->result;
	}
	dest->result = dest->tofree;	
	(*env)->GetByteArrayRegion(env, bytes, 0, len, (jbyte *) dest->result);
	dest->result[len] = '\0';
    } else {
	(*env)->DeleteLocalRef(env, exc);
    }
    return dest->result;
}

static jstring
trans2utf(JNIEnv *env, int haveutf, jstring enc, const char *src,
	  transstr *dest)
{
    jbyteArray bytes = 0;
    int len;

    dest->result = 0;
    dest->tofree = 0;
    dest->jstr = 0;
    if (!src) {
	return dest->jstr;
    }
    if (haveutf) {
	dest->jstr = (*env)->NewStringUTF(env, src);
	return dest->jstr;
    }
    len = strlen(src);
    bytes = (*env)->NewByteArray(env, len);
    if (bytes) {
	(*env)->SetByteArrayRegion(env, bytes, 0, len, (jbyte *) src);
	if (enc) {
	    dest->jstr =
		(*env)->NewObject(env, C_java_lang_String,
				  M_java_lang_String_initBytes2, bytes, enc);
	} else {
	    dest->jstr =
		(*env)->NewObject(env, C_java_lang_String,
				  M_java_lang_String_initBytes, bytes);
	}
	(*env)->DeleteLocalRef(env, bytes);
	return dest->jstr;
    }
    throwoom(env, "string translation failed");
    return dest->jstr;
}

#if HAVE_SQLITE2
static int
busyhandler(void *udata, const char *table, int count)
{
    handle *h = (handle *) udata;
    JNIEnv *env = h->env;
    int ret = 0;

    if (env && h->bh) {
	transstr tabstr;
	jclass cls = (*env)->GetObjectClass(env, h->bh);
	jmethodID mid = (*env)->GetMethodID(env, cls, "busy",
					    "(Ljava/lang/String;I)Z");

	if (mid == 0) {
	    return ret;
	}
	trans2utf(env, h->haveutf, h->enc, table, &tabstr);
	ret = (*env)->CallBooleanMethod(env, h->bh, mid, tabstr.jstr,
					(jint) count)
	      != JNI_FALSE;
	(*env)->DeleteLocalRef(env, tabstr.jstr);
    }
    return ret;
}
#endif

#if HAVE_SQLITE3
static int
busyhandler3(void *udata, int count)
{
    handle *h = (handle *) udata;
    JNIEnv *env = h->env;
    int ret = 0;

    if (env && h->bh) {
	jclass cls = (*env)->GetObjectClass(env, h->bh);
	jmethodID mid = (*env)->GetMethodID(env, cls, "busy",
					    "(Ljava/lang/String;I)Z");

	if (mid == 0) {
	    return ret;
	}
	ret = (*env)->CallBooleanMethod(env, h->bh, mid, 0, (jint) count)
	    != JNI_FALSE;
    }
    return ret;
}
#endif

static int
progresshandler(void *udata)
{
    handle *h = (handle *) udata;
    JNIEnv *env = h->env;
    int ret = 0;

    if (env && h->ph) {
	jclass cls = (*env)->GetObjectClass(env, h->ph);
	jmethodID mid = (*env)->GetMethodID(env, cls, "progress", "()Z");

	if (mid == 0) {
	    return ret;
	}
	ret = (*env)->CallBooleanMethod(env, h->ph, mid) != JNI_TRUE;
    }
    return ret;
}

static int
callback(void *udata, int ncol, char **data, char **cols)
{
    handle *h = (handle *) udata;
    JNIEnv *env = h->env;

    if (env && h->cb) {
	jthrowable exc;
	jclass cls = (*env)->GetObjectClass(env, h->cb);
	jmethodID mid;
	jobjectArray arr = 0;
	jint i;

	if (h->row1) {
	    mid = (*env)->GetMethodID(env, cls, "columns",
				      "([Ljava/lang/String;)V");

	    if (mid) {
		arr = (*env)->NewObjectArray(env, ncol, C_java_lang_String, 0);
		for (i = 0; i < ncol; i++) {
		    if (cols[i]) {
			transstr col;

			trans2utf(env, h->haveutf, h->enc, cols[i], &col);
			(*env)->SetObjectArrayElement(env, arr, i, col.jstr);
			exc = (*env)->ExceptionOccurred(env);
			if (exc) {
			    (*env)->DeleteLocalRef(env, exc);
			    return 1;
			}
			(*env)->DeleteLocalRef(env, col.jstr);
		    }
		}
		h->row1 = 0;
		(*env)->CallVoidMethod(env, h->cb, mid, arr);
		exc = (*env)->ExceptionOccurred(env);
		if (exc) {
		    (*env)->DeleteLocalRef(env, exc);
		    return 1;
		}
		(*env)->DeleteLocalRef(env, arr);
	    }
#if HAVE_BOTH_SQLITE
	    if (h->is3) {
		mid = (*env)->GetMethodID(env, cls, "types",
					  "([Ljava/lang/String;)V");

		if (mid && h->stmt) {
		    arr = (*env)->NewObjectArray(env, ncol,
						 C_java_lang_String, 0);
		    for (i = 0; i < ncol; i++) {
			const char *ctype =
			    sqlite3_column_decltype(h->stmt, i);

			if (!ctype) {
			    switch (sqlite3_column_type(h->stmt, i)) {
			    case SQLITE_INTEGER: ctype = "integer"; break;
			    case SQLITE_FLOAT:   ctype = "double";  break;
			    default:
#if defined(SQLITE_TEXT) && defined(SQLITE3_TEXT) && (SQLITE_TEXT != SQLITE3_TEXT)
			    case SQLITE_TEXT:
#else
#ifdef SQLITE3_TEXT
			    case SQLITE3_TEXT:
#endif
#endif
						 ctype = "text";    break;
			    case SQLITE_BLOB:    ctype = "blob";    break;
			    case SQLITE_NULL:    ctype = "null";    break;
			    }
			}
			if (ctype) {
			    transstr ty;

			    trans2utf(env, 1, 0, ctype, &ty);
			    (*env)->SetObjectArrayElement(env, arr, i,
							  ty.jstr);
			    exc = (*env)->ExceptionOccurred(env);
			    if (exc) {
				(*env)->DeleteLocalRef(env, exc);
				return 1;
			    }
			    (*env)->DeleteLocalRef(env, ty.jstr);
			}
		    }
		    (*env)->CallVoidMethod(env, h->cb, mid, arr);
		    exc = (*env)->ExceptionOccurred(env);
		    if (exc) {
			(*env)->DeleteLocalRef(env, exc);
			return 1;
		    }
		    (*env)->DeleteLocalRef(env, arr);
		}
	    } else {
		if (h->ver >= 0x020506 && cols[ncol]) {
		    mid = (*env)->GetMethodID(env, cls, "types",
					      "([Ljava/lang/String;)V");

		    if (mid) {
			arr = (*env)->NewObjectArray(env, ncol,
						     C_java_lang_String, 0);
			for (i = 0; i < ncol; i++) {
			    if (cols[i + ncol]) {
				transstr ty;

				trans2utf(env, h->haveutf, h->enc,
					  cols[i + ncol], &ty);
				(*env)->SetObjectArrayElement(env, arr, i,
							      ty.jstr);
				exc = (*env)->ExceptionOccurred(env);
				if (exc) {
				    (*env)->DeleteLocalRef(env, exc);
				    return 1;
				}
				(*env)->DeleteLocalRef(env, ty.jstr);
			    }
			}
			(*env)->CallVoidMethod(env, h->cb, mid, arr);
			exc = (*env)->ExceptionOccurred(env);
			if (exc) {
			    (*env)->DeleteLocalRef(env, exc);
			    return 1;
			}
			(*env)->DeleteLocalRef(env, arr);
		    }
		}
	    }
#else
#if HAVE_SQLITE2
	    if (h->ver >= 0x020506 && cols[ncol]) {
		mid = (*env)->GetMethodID(env, cls, "types",
					  "([Ljava/lang/String;)V");

		if (mid) {
		    arr = (*env)->NewObjectArray(env, ncol,
						 C_java_lang_String, 0);
		    for (i = 0; i < ncol; i++) {
			if (cols[i + ncol]) {
			    transstr ty;

			    trans2utf(env, h->haveutf, h->enc,
				      cols[i + ncol], &ty);
			    (*env)->SetObjectArrayElement(env, arr, i,
							  ty.jstr);
			    exc = (*env)->ExceptionOccurred(env);
			    if (exc) {
				(*env)->DeleteLocalRef(env, exc);
				return 1;
			    }
			    (*env)->DeleteLocalRef(env, ty.jstr);
			}
		    }
		    (*env)->CallVoidMethod(env, h->cb, mid, arr);
		    exc = (*env)->ExceptionOccurred(env);
		    if (exc) {
			(*env)->DeleteLocalRef(env, exc);
			return 1;
		    }
		    (*env)->DeleteLocalRef(env, arr);
		}
	    }
#endif
#if HAVE_SQLITE3
	    mid = (*env)->GetMethodID(env, cls, "types",
				      "([Ljava/lang/String;)V");

	    if (mid && h->stmt) {
		arr = (*env)->NewObjectArray(env, ncol,
					     C_java_lang_String, 0);
		for (i = 0; i < ncol; i++) {
		    const char *ctype = sqlite3_column_decltype(h->stmt, i);

		    if (!ctype) {
			switch (sqlite3_column_type(h->stmt, i)) {
			case SQLITE_INTEGER: ctype = "integer"; break;
			case SQLITE_FLOAT:   ctype = "double";  break;
			default:
#if defined(SQLITE_TEXT) && defined(SQLITE3_TEXT) && (SQLITE_TEXT != SQLITE3_TEXT)
			case SQLITE_TEXT:
#else
#ifdef SQLITE3_TEXT
			case SQLITE3_TEXT:
#endif
#endif
					     ctype = "text";    break;
			case SQLITE_BLOB:    ctype = "blob";    break;
			case SQLITE_NULL:    ctype = "null";    break;
			}
		    }
		    if (ctype) {
			transstr ty;

			trans2utf(env, 1, 0, ctype, &ty);
			(*env)->SetObjectArrayElement(env, arr, i, ty.jstr);
			exc = (*env)->ExceptionOccurred(env);
			if (exc) {
			    (*env)->DeleteLocalRef(env, exc);
			    return 1;
			}
			(*env)->DeleteLocalRef(env, ty.jstr);
		    }
		}
		(*env)->CallVoidMethod(env, h->cb, mid, arr);
		exc = (*env)->ExceptionOccurred(env);
		if (exc) {
		    (*env)->DeleteLocalRef(env, exc);
		    return 1;
		}
		(*env)->DeleteLocalRef(env, arr);
	    }
#endif
#endif
	}
	mid = (*env)->GetMethodID(env, cls, "newrow",
				  "([Ljava/lang/String;)Z");
	if (mid) {
	    jboolean rc;

	    if (data) {
		arr = (*env)->NewObjectArray(env, ncol, C_java_lang_String, 0);
	    } else {
		arr = 0;
	    }
	    for (i = 0; arr && i < ncol; i++) {
		if (data[i]) {
		    transstr dats;

		    trans2utf(env, h->haveutf, h->enc, data[i], &dats);
		    (*env)->SetObjectArrayElement(env, arr, i, dats.jstr);
		    exc = (*env)->ExceptionOccurred(env);
		    if (exc) {
			(*env)->DeleteLocalRef(env, exc);
			return 1;
		    }
		    (*env)->DeleteLocalRef(env, dats.jstr);
		}
	    }
	    rc = (*env)->CallBooleanMethod(env, h->cb, mid, arr);
	    exc = (*env)->ExceptionOccurred(env);
	    if (exc) {
		(*env)->DeleteLocalRef(env, exc);
		return 1;
	    }
	    if (arr) {
		(*env)->DeleteLocalRef(env, arr);
	    }
	    (*env)->DeleteLocalRef(env, cls);
	    return rc != JNI_FALSE;
	}
    }
    return 0;
}

static void
doclose(JNIEnv *env, jobject obj, int final)
{
    handle *h = gethandle(env, obj);

    if (h) {
	hfunc *f;
#if HAVE_SQLITE_COMPILE
	hvm *v;

	while ((v = h->vms)) {
	    h->vms = v->next;
	    v->next = 0;
	    v->h = 0;
	    if (v->vm) {
#if HAVE_BOTH_SQLITE
		if (h->is3) {
		    sqlite3_finalize((sqlite3_stmt *) v->vm);
		} else {
		    sqlite_finalize((sqlite_vm *) v->vm, 0);
		}
#else
#if HAVE_SQLITE2
		sqlite_finalize((sqlite_vm *) v->vm, 0);
#endif
#if HAVE_SQLITE3
		sqlite3_finalize((sqlite3_stmt *) v->vm);
#endif
#endif
		v->vm = 0;
	    }
	}
#endif
	if (h->sqlite) {
#if HAVE_BOTH_SQLITE
	    if (h->is3) {
		sqlite3_close((sqlite3 *) h->sqlite);
	    } else {
		sqlite_close((sqlite *) h->sqlite);
	    }
#else
#if HAVE_SQLITE2
	    sqlite_close((sqlite *) h->sqlite);
#endif
#if HAVE_SQLITE3
	    sqlite3_close((sqlite3 *) h->sqlite);
#endif
#endif
	    h->sqlite = 0;
	}
	while ((f = h->funcs)) {
	    h->funcs = f->next;
	    f->h = 0;
	    f->sf = 0;
	    f->env = 0;
	    if (f->fc) {
		(*env)->SetLongField(env, f->fc,
				     F_SQLite_FunctionContext_handle, 0);
	    }
	    delglobrefp(env, &f->db);
	    delglobrefp(env, &f->fi);
	    delglobrefp(env, &f->fc);
	    free(f);
	}
	delglobrefp(env, &h->bh);
	delglobrefp(env, &h->cb);
	delglobrefp(env, &h->ai);
	delglobrefp(env, &h->tr);
	delglobrefp(env, &h->ph);
	delglobrefp(env, &h->enc);
	free(h);
	(*env)->SetLongField(env, obj, F_SQLite_Database_handle, 0);
	return;
    }
    if (!final) {
	throwclosed(env);
    }
}

JNIEXPORT void JNICALL
Java_SQLite_Database_close(JNIEnv *env, jobject obj)
{
    doclose(env, obj, 0);
}

JNIEXPORT void JNICALL
Java_SQLite_Database_finalize(JNIEnv *env, jobject obj)
{
    doclose(env, obj, 1);
}

JNIEXPORT void JNICALL
Java_SQLite_Database_busy_1timeout(JNIEnv *env, jobject obj, jint ms)
{
    handle *h = gethandle(env, obj);

    if (h && h->sqlite) {
#if HAVE_BOTH_SQLITE
	if (h->is3) {
	    sqlite3_busy_timeout((sqlite3 * ) h->sqlite, ms);
	} else {
	    sqlite_busy_timeout((sqlite *) h->sqlite, ms);
	}
#else
#if HAVE_SQLITE2
	sqlite_busy_timeout((sqlite *) h->sqlite, ms);
#endif
#if HAVE_SQLITE3
	sqlite3_busy_timeout((sqlite3 * ) h->sqlite, ms);
#endif
#endif
	return;
    }
    throwclosed(env);
}

JNIEXPORT jstring JNICALL
Java_SQLite_Database_version(JNIEnv *env, jclass cls)
{
    /* CHECK THIS */
#if HAVE_BOTH_SQLITE
    return (*env)->NewStringUTF(env, sqlite_libversion());
#else
#if HAVE_SQLITE2
    return (*env)->NewStringUTF(env, sqlite_libversion());
#else
    return (*env)->NewStringUTF(env, sqlite3_libversion());
#endif
#endif
}

JNIEXPORT jstring JNICALL
Java_SQLite_Database_dbversion(JNIEnv *env, jobject obj)
{
    handle *h = gethandle(env, obj);

    if (h && h->sqlite) {
#if HAVE_BOTH_SQLITE
	if (h->is3) {
	    return (*env)->NewStringUTF(env, sqlite3_libversion());
	} else {
	    return (*env)->NewStringUTF(env, sqlite_libversion());
	}
#else
#if HAVE_SQLITE2
	return (*env)->NewStringUTF(env, sqlite_libversion());
#else
	return (*env)->NewStringUTF(env, sqlite3_libversion());
#endif
#endif
    }
    return (*env)->NewStringUTF(env, "unknown");
}

JNIEXPORT jlong JNICALL
Java_SQLite_Database_last_1insert_1rowid(JNIEnv *env, jobject obj)
{
    handle *h = gethandle(env, obj);

    if (h && h->sqlite) {
#if HAVE_BOTH_SQLITE
	if (h->is3) {
	    return (jlong) sqlite3_last_insert_rowid((sqlite3 *) h->sqlite);
	} else {
	    return (jlong) sqlite_last_insert_rowid((sqlite *) h->sqlite);
	}
#else
#if HAVE_SQLITE2
	return (jlong) sqlite_last_insert_rowid((sqlite *) h->sqlite);
#endif
#if HAVE_SQLITE3
	return (jlong) sqlite3_last_insert_rowid((sqlite3 *) h->sqlite);
#endif
#endif
    }
    throwclosed(env);
    return (jlong) 0;
}

JNIEXPORT jlong JNICALL
Java_SQLite_Database_changes(JNIEnv *env, jobject obj)
{
    handle *h = gethandle(env, obj);

    if (h && h->sqlite) {
#if HAVE_BOTH_SQLITE
	if (h->is3) {
	    return (jlong) sqlite3_changes((sqlite3 *) h->sqlite);
	} else {
	    return (jlong) sqlite_changes((sqlite *) h->sqlite);
	}
#else
#if HAVE_SQLITE2
	return (jlong) sqlite_changes((sqlite *) h->sqlite);
#endif
#if HAVE_SQLITE3
	return (jlong) sqlite3_changes((sqlite3 *) h->sqlite);
#endif
#endif
    }
    throwclosed(env);
    return (jlong) 0;
}

JNIEXPORT jboolean JNICALL
Java_SQLite_Database_complete(JNIEnv *env, jclass cls, jstring sql)
{
    transstr sqlstr;
    jboolean result;

    if (!sql) {
	return JNI_FALSE;
    }
#if HAVE_BOTH_SQLITE || HAVE_SQLITE3
    /* CHECK THIS */
    trans2iso(env, 1, 0, sql, &sqlstr);
    result = sqlite3_complete(sqlstr.result) ? JNI_TRUE : JNI_FALSE;
#else
    trans2iso(env, strcmp(sqlite_libencoding(), "UTF-8") == 0, 0,
	      sql, &sqlstr);
    result = sqlite_complete(sqlstr.result) ? JNI_TRUE : JNI_FALSE;
#endif
    transfree(&sqlstr);
    return result;
}

JNIEXPORT void JNICALL
Java_SQLite_Database_interrupt(JNIEnv *env, jobject obj)
{
    handle *h = gethandle(env, obj);

    if (h && h->sqlite) {
#if HAVE_BOTH_SQLITE
	if (h->is3) {
	    sqlite3_interrupt((sqlite3 *) h->sqlite);
	} else {
	    sqlite_interrupt((sqlite *) h->sqlite);
	}
#else
#if HAVE_SQLITE2
	sqlite_interrupt((sqlite *) h->sqlite);
#endif
#if HAVE_SQLITE3
	sqlite3_interrupt((sqlite3 *) h->sqlite);
#endif
#endif
	return;
    }
    throwclosed(env);
}

JNIEXPORT void JNICALL
Java_SQLite_Database_open(JNIEnv *env, jobject obj, jstring file, jint mode)
{
    handle *h = gethandle(env, obj);
    jthrowable exc;
    char *err = 0;
    transstr filename;
    int maj, min, lev;

    if (h) {
	if (h->sqlite) {
#if HAVE_BOTH_SQLITE
	    if (h->is3) {
		sqlite3_close((sqlite3 *) h->sqlite);
	    } else {
		sqlite_close((sqlite *) h->sqlite);
	    }
	    h->is3 = 0;
#else
#if HAVE_SQLITE2
	    sqlite_close((sqlite *) h->sqlite);
#endif
#if HAVE_SQLITE3
	    sqlite3_close((sqlite3 *) h->sqlite);
#endif
#endif
	    h->sqlite = 0;
	}
    } else {
	h = malloc(sizeof (handle));
	if (!h) {
	    throwoom(env, "unable to get SQLite handle");
	    return;
	}
	h->sqlite = 0;
	h->bh = h->cb = h->ai = h->tr = h->ph = 0;
	/* CHECK THIS */
#if HAVE_BOTH_SQLITE
	h->is3 = 0;
	h->stmt = 0;
	h->haveutf = 1;
#else
#if HAVE_SQLITE2
	h->haveutf = strcmp(sqlite_libencoding(), "UTF-8") == 0;
#endif
#if HAVE_SQLITE3
	h->stmt = 0;
	h->haveutf = 1;
#endif
#endif
	h->enc = 0;
	h->funcs = 0;
	h->ver = 0;
#if HAVE_SQLITE_COMPILE
	h->vms = 0;
#endif
    }
    h->env = 0;
    if (!file) {
	throwex(env, err ? err : "invalid file name");
	return;
    }
    trans2iso(env, h->haveutf, h->enc, file, &filename);
    exc = (*env)->ExceptionOccurred(env);
    if (exc) {
	(*env)->DeleteLocalRef(env, exc);
	return;
    }
#if HAVE_BOTH_SQLITE
    {
	/* CHECK THIS */

	FILE *f = fopen(filename.result, "rb");
	int c_0 = EOF;

	if (f) {
	    c_0 = fgetc(f);
	    fclose(f);
	}
	if (c_0 != '*') {
	    int rc = sqlite3_open(filename.result, (sqlite3 **) &h->sqlite);

	    if (rc == SQLITE_OK) {
		h->is3 = 1;
	    }
	} else {
	    h->sqlite = (void *) sqlite_open(filename.result,
					     (int) mode, &err);
	}
    }
#else
#if HAVE_SQLITE2
    h->sqlite = (void *) sqlite_open(filename.result, (int) mode, &err);
#endif
#if HAVE_SQLITE3
    sqlite3_open(filename.result, (sqlite3 **) &h->sqlite);
#endif
#endif
    transfree(&filename);
    exc = (*env)->ExceptionOccurred(env);
    if (exc) {
	(*env)->DeleteLocalRef(env, exc);
#if HAVE_SQLITE2
	if (err) {
	    sqlite_freemem(err);
	}
#endif
	if (h->sqlite) {
#if HAVE_BOTH_SQLITE
	    if (h->is3) {
		sqlite3_close((sqlite3 *) h->sqlite);
		h->is3 = 0;
	    } else {
		sqlite_close((sqlite *) h->sqlite);
	    }
#else
#if HAVE_SQLITE2
	    sqlite_close((sqlite *) h->sqlite);
#endif
#if HAVE_SQLITE3
	    sqlite3_close((sqlite3 *) h->sqlite);
#endif
#endif
	}
	free(h);
	return;
    }
    if (h->sqlite) {
	jvalue v;

	v.j = 0;
	v.l = (jobject) h;
	(*env)->SetLongField(env, obj, F_SQLite_Database_handle, v.j);
#if HAVE_SQLITE2
	if (err) {
	    sqlite_freemem(err);
	}
#endif
#if HAVE_BOTH_SQLITE
	if (h->is3) {
	    sscanf(sqlite3_libversion(), "%d.%d.%d", &maj, &min, &lev);
	} else {
	    sscanf(sqlite_libversion(), "%d.%d.%d", &maj, &min, &lev);
	}
#else
#if HAVE_SQLITE2
	sscanf(sqlite_libversion(), "%d.%d.%d", &maj, &min, &lev);
#endif
#if HAVE_SQLITE3
	sscanf(sqlite3_libversion(), "%d.%d.%d", &maj, &min, &lev);
#endif
#endif
	h->ver = ((maj & 0xFF) << 16) | ((min & 0xFF) << 8) | (lev & 0xFF);
	return;
    }
    throwex(env, err ? err : "unknown error in open");
#if HAVE_SQLITE2
    if (err) {
	sqlite_freemem(err);
    }
#endif
}

JNIEXPORT void JNICALL
Java_SQLite_Database_open_1aux_1file(JNIEnv *env, jobject obj, jstring file)
{
    handle *h = gethandle(env, obj);
#if HAVE_SQLITE_OPEN_AUX_FILE
    jboolean b;
    jthrowable exc;
    char *err = 0;
    transstr filename;
    int ret;
#endif

    if (h && h->sqlite) {
#if HAVE_SQLITE_OPEN_AUX_FILE
#if HAVE_BOTH_SQLITE
	if (h->is3) {
	    throwex(env, "unsupported");
	}
#endif
	trans2iso(env, h->haveutf, h->enc, file, &filename);
	exc = (*env)->ExceptionOccurred(env);
	if (exc) {
	    (*env)->DeleteLocalRef(env, exc);
	    return;
	}
	ret = sqlite_open_aux_file((sqlite *) h->sqlite,
				   filename.result, &err);
	transfree(&filename);
	exc = (*env)->ExceptionOccurred(env);
	if (exc) {
	    (*env)->DeleteLocalRef(env, exc);
	    if (err) {
		sqlite_freemem(err);
	    }
	    return;
	}
	if (ret != SQLITE_OK) {
	    throwex(env, err ? err : sqlite_error_string(ret));
	}
	if (err) {
	    sqlite_freemem(err);
	}
#else
	throwex(env, "unsupported");
#endif
	return;
    }
    throwclosed(env);
}

JNIEXPORT void JNICALL
Java_SQLite_Database_busy_1handler(JNIEnv *env, jobject obj, jobject bh)
{
    handle *h = gethandle(env, obj);

    if (h && h->sqlite) {
	delglobrefp(env, &h->bh);
	globrefset(env, bh, &h->bh);
#if HAVE_BOTH_SQLITE
	if (h->is3) {
	    sqlite3_busy_handler((sqlite3 *) h->sqlite, busyhandler3, h);
	} else {
	    sqlite_busy_handler((sqlite *) h->sqlite, busyhandler, h);
	}
#else
#if HAVE_SQLITE2
	sqlite_busy_handler((sqlite *) h->sqlite, busyhandler, h);
#endif
#if HAVE_SQLITE3
	sqlite3_busy_handler((sqlite3 *) h->sqlite, busyhandler3, h);
#endif
#endif
	return;
    }
    throwclosed(env);
}

JNIEXPORT void JNICALL
Java_SQLite_Database_exec__Ljava_lang_String_2LSQLite_Callback_2
    (JNIEnv *env, jobject obj, jstring sql, jobject cb)
{
    handle *h = gethandle(env, obj);
    freemem *freeproc;

    if (!sql) {
	throwex(env, "invalid SQL statement");
	return;
    }
    if (h) {
	if (h->sqlite) {
	    jthrowable exc;
	    int rc;
	    char *err = 0;
	    transstr sqlstr;
	    jobject oldcb = globrefpop(env, &h->cb);

	    globrefset(env, cb, &h->cb);
	    h->env = env;
	    h->row1 = 1;
	    trans2iso(env, h->haveutf, h->enc, sql, &sqlstr);
	    exc = (*env)->ExceptionOccurred(env);
	    if (exc) {
		(*env)->DeleteLocalRef(env, exc);
		return;
	    }
#if HAVE_BOTH_SQLITE
	    if (h->is3) {
		rc = sqlite3_exec((sqlite3 *) h->sqlite, sqlstr.result,
				  callback, h, &err);
		freeproc = (freemem *) sqlite3_free;
	    } else {
		rc = sqlite_exec((sqlite *) h->sqlite, sqlstr.result,
				 callback, h, &err);
		freeproc = (freemem *) sqlite_freemem;
	    }
#else
#if HAVE_SQLITE2
	    rc = sqlite_exec((sqlite *) h->sqlite, sqlstr.result,
			     callback, h, &err);
	    freeproc = (freemem *) sqlite_freemem;
#endif
#if HAVE_SQLITE3
	    rc = sqlite3_exec((sqlite3 *) h->sqlite, sqlstr.result,
			      callback, h, &err);
	    freeproc = (freemem *) sqlite3_free;
#endif
#endif
	    transfree(&sqlstr);
	    exc = (*env)->ExceptionOccurred(env);
	    delglobrefp(env, &h->cb);
	    h->cb = oldcb;
	    if (exc) {
		(*env)->DeleteLocalRef(env, exc);
		if (err) {
		    freeproc(err);
		}
		return;
	    }
	    if (rc != SQLITE_OK) {
		seterr(env, obj, rc);
		throwex(env, err ? err : "unknown error in sqlite*_exec");
	    }
	    if (err) {
		freeproc(err);
	    }
	    return;
	}
    }
    throwclosed(env);
}

JNIEXPORT void JNICALL
Java_SQLite_Database_exec__Ljava_lang_String_2LSQLite_Callback_2_3Ljava_lang_String_2
    (JNIEnv *env, jobject obj, jstring sql, jobject cb, jobjectArray args)
{
    handle *h = gethandle(env, obj);
    freemem *freeproc = 0;

    if (!sql) {
	throwex(env, "invalid SQL statement");
	return;
    }
    if (h) {
	if (h->sqlite) {
	    jboolean b;
	    jthrowable exc;
	    int rc = SQLITE_ERROR, nargs, i;
	    char *err = 0, *p;
	    const char *str = (*env)->GetStringUTFChars(env, sql, &b);
	    transstr sqlstr;
	    struct args {
		char *arg;
		jobject obj;
		transstr trans;
	    } *argv = 0;
	    char **cargv = 0;
	    jobject oldcb = globrefpop(env, &h->cb);

	    globrefset(env, cb, &h->cb);
	    p = (char *) str;
	    nargs = 0;
	    while (*p) {
		if (*p == '%') {
		    ++p;
		    if (*p == 'q') {
			nargs++;
		    } else if (h->ver >= 0x020500 && *p == 'Q') {
			nargs++;
		    } else if (*p != '%') {
			(*env)->ReleaseStringUTFChars(env, sql, str);
			delglobrefp(env, &h->cb);
			h->cb = oldcb;
			throwex(env, "bad % specification in query");
			return;
		    }
		}
		++p;
	    }
	    if (nargs) {
		cargv = malloc((sizeof (*argv) + sizeof (char *)) * nargs);

		if (!cargv) {
		    (*env)->ReleaseStringUTFChars(env, sql, str);
		    delglobrefp(env, &h->cb);
		    h->cb = oldcb;
		    throwoom(env, "unable to allocate arg vector");
		    return;
		}
		argv = (struct args *) (cargv + nargs);
		for (i = 0; i < nargs; i++) {
		    cargv[i] = 0;
		    argv[i].arg = 0;
		    argv[i].obj = 0;
		    argv[i].trans.result = argv[i].trans.tofree = 0;
		}
	    }
	    exc = 0;
	    for (i = 0; i < nargs; i++) {
		jobject so = (*env)->GetObjectArrayElement(env, args, i);

		exc = (*env)->ExceptionOccurred(env);
		if (exc) {
		    (*env)->DeleteLocalRef(env, exc);
		    break;
		}
		if (so) {
		    argv[i].obj = so;
		    argv[i].arg = cargv[i] =
			trans2iso(env, h->haveutf, h->enc, argv[i].obj,
				  &argv[i].trans);
		}
	    }
	    if (exc) {
		for (i = 0; i < nargs; i++) {
		    if (argv[i].obj) {
			transfree(&argv[i].trans);
		    }
		}
		freep((char **) &cargv);
		delglobrefp(env, &h->cb);
		h->cb = oldcb;
		return;
	    }
	    h->env = env;
	    h->row1 = 1;
	    trans2iso(env, h->haveutf, h->enc, sql, &sqlstr);
	    exc = (*env)->ExceptionOccurred(env);
	    if (!exc) {
#if HAVE_BOTH_SQLITE
		if (h->is3) {
		    char *s = sqlite3_vmprintf(sqlstr.result, (char *) cargv);
		    if (s) {
			rc = sqlite3_exec((sqlite3 *) h->sqlite, s, callback,
					  h, &err);
			sqlite3_free(s);
		    } else {
			rc = SQLITE_NOMEM;
		    }
		    freeproc = (freemem *) sqlite3_free;
		} else {
		    rc = sqlite_exec_vprintf((sqlite *) h->sqlite,
					     sqlstr.result, callback,
					     h, &err, (char *) cargv);
		    freeproc = (freemem *) sqlite_freemem;
		}
#else
#if HAVE_SQLITE2
		rc = sqlite_exec_vprintf((sqlite *) h->sqlite, sqlstr.result,
					 callback, h, &err, (char *) cargv);
		freeproc = (freemem *) sqlite_freemem;
#endif
#if HAVE_SQLITE3
		char *s = sqlite3_vmprintf(sqlstr.result, (char *) cargv);
		if (s) {
		    rc = sqlite3_exec((sqlite3 *) h->sqlite, s, callback,
				      h, &err);
		    sqlite3_free(s);
		} else {
		    rc = SQLITE_NOMEM;
		}
		freeproc = (freemem *) sqlite3_free;
#endif
#endif
		exc = (*env)->ExceptionOccurred(env);
	    }
	    for (i = 0; i < nargs; i++) {
		if (argv[i].obj) {
		    transfree(&argv[i].trans);
		}
	    }
	    transfree(&sqlstr);
	    freep((char **) &cargv);
	    delglobrefp(env, &h->cb);
	    h->cb = oldcb;
	    if (exc) {
		(*env)->DeleteLocalRef(env, exc);
		if (err && freeproc) {
		    freeproc(err);
		}
		return;
	    }
	    if (rc != SQLITE_OK) {
		seterr(env, obj, rc);
		throwex(env, err ? err : "unknown error in sqlite*_exec");
	    }
	    if (err && freeproc) {
		freeproc(err);
	    }
	    return;
	}
    }
    throwclosed(env);
}

static hfunc *
getfunc(JNIEnv *env, jobject obj)
{
    jvalue v;

    v.j = (*env)->GetLongField(env, obj, F_SQLite_FunctionContext_handle);
    return (hfunc *) v.l;
}

#if HAVE_SQLITE2
static void
call_common(sqlite_func *sf, int isstep, int nargs, const char **args)
{
    hfunc *f = (hfunc *) sqlite_user_data(sf);

    if (f && f->env && f->fi) {
	JNIEnv *env = f->env;
	jclass cls = (*env)->GetObjectClass(env, f->fi);
	jmethodID mid =
	    (*env)->GetMethodID(env, cls,
				isstep ? "step" : "function",
				"(LSQLite/FunctionContext;[Ljava/lang/String;)V");
	jobjectArray arr;
	int i;

	if (mid == 0) {
	    return;
	}
	arr = (*env)->NewObjectArray(env, nargs, C_java_lang_String, 0);
	for (i = 0; i < nargs; i++) {
	    if (args[i]) {
		transstr arg;
		jthrowable exc;

		trans2utf(env, f->h->haveutf, f->h->enc, args[i], &arg);
		(*env)->SetObjectArrayElement(env, arr, i, arg.jstr);
		exc = (*env)->ExceptionOccurred(env);
		if (exc) {
		    (*env)->DeleteLocalRef(env, exc);
		    return;
		}
		(*env)->DeleteLocalRef(env, arg.jstr);
	    }
	}
	f->sf = sf;
	(*env)->CallVoidMethod(env, f->fi, mid, f->fc, arr);
	(*env)->DeleteLocalRef(env, arr);
	(*env)->DeleteLocalRef(env, cls);
    }
}

static void
call_func(sqlite_func *sf, int nargs, const char **args)
{
    call_common(sf, 0, nargs, args);
}

static void
call_step(sqlite_func *sf, int nargs, const char **args)
{
    call_common(sf, 1, nargs, args);
}

static void
call_final(sqlite_func *sf)
{
    hfunc *f = (hfunc *) sqlite_user_data(sf);

    if (f && f->env && f->fi) {
	JNIEnv *env = f->env;
	jclass cls = (*env)->GetObjectClass(env, f->fi);
	jmethodID mid = (*env)->GetMethodID(env, cls, "last_step",
					    "(LSQLite/FunctionContext;)V");
	if (mid == 0) {
	    return;
	}
	f->sf = sf;
	(*env)->CallVoidMethod(env, f->fi, mid, f->fc);
	(*env)->DeleteLocalRef(env, cls);
    }
}
#endif

#if HAVE_SQLITE3
static void
call3_common(sqlite3_context *sf, int isstep, int nargs, sqlite3_value **args)
{
    hfunc *f = (hfunc *) sqlite3_user_data(sf);

    if (f && f->env && f->fi) {
	JNIEnv *env = f->env;
	jclass cls = (*env)->GetObjectClass(env, f->fi);
	jmethodID mid =
	    (*env)->GetMethodID(env, cls,
				isstep ? "step" : "function",
				"(LSQLite/FunctionContext;[Ljava/lang/String;)V");
	jobjectArray arr;
	int i;

	if (mid == 0) {
	    return;
	}
	arr = (*env)->NewObjectArray(env, nargs, C_java_lang_String, 0);
	for (i = 0; i < nargs; i++) {
	    if (args[i]) {
		transstr arg;
		jthrowable exc;

		trans2utf(env, 1, 0, sqlite3_value_text(args[i]), &arg);
		(*env)->SetObjectArrayElement(env, arr, i, arg.jstr);
		exc = (*env)->ExceptionOccurred(env);
		if (exc) {
		    (*env)->DeleteLocalRef(env, exc);
		    return;
		}
		(*env)->DeleteLocalRef(env, arg.jstr);
	    }
	}
	f->sf = sf;
	(*env)->CallVoidMethod(env, f->fi, mid, f->fc, arr);
	(*env)->DeleteLocalRef(env, arr);
	(*env)->DeleteLocalRef(env, cls);
    }
}

static void
call3_func(sqlite3_context *sf, int nargs, sqlite3_value **args)
{
    call3_common(sf, 0, nargs, args);
}

static void
call3_step(sqlite3_context *sf, int nargs, sqlite3_value **args)
{
    call3_common(sf, 1, nargs, args);
}

static void
call3_final(sqlite3_context *sf)
{
    hfunc *f = (hfunc *) sqlite3_user_data(sf);

    if (f && f->env && f->fi) {
	JNIEnv *env = f->env;
	jclass cls = (*env)->GetObjectClass(env, f->fi);
	jmethodID mid = (*env)->GetMethodID(env, cls, "last_step",
					    "(LSQLite/FunctionContext;)V");
	if (mid == 0) {
	    return;
	}
	f->sf = sf;
	(*env)->CallVoidMethod(env, f->fi, mid, f->fc);
	(*env)->DeleteLocalRef(env, cls);
    }
}
#endif

static void
mkfunc_common(JNIEnv *env, int isagg, jobject obj, jstring name,
	      jint nargs, jobject fi)
{
    handle *h = gethandle(env, obj);

    if (h && h->sqlite) {
	jclass cls = (*env)->FindClass(env, "SQLite/FunctionContext");
	jobject fc;
	hfunc *f;
	int ret;
	transstr namestr;
	jvalue v;
	jthrowable exc;

	fc = (*env)->AllocObject(env, cls);
	if (!fi) {
	    throwex(env, "null SQLite.Function not allowed");
	    return;
	}
	f = malloc(sizeof (hfunc));
	if (!f) {
	    throwoom(env, "unable to get SQLite.FunctionContext handle");
	    return;
	}
	globrefset(env, fc, &f->fc);
	globrefset(env, fi, &f->fi);
	globrefset(env, obj, &f->db);
	f->h = h;
	f->next = h->funcs;
	h->funcs = f;
	f->sf = 0;
	f->env = env;
	v.j = 0;
	v.l = (jobject) f;
	(*env)->SetLongField(env, f->fc, F_SQLite_FunctionContext_handle, v.j);
	trans2iso(env, h->haveutf, h->enc, name, &namestr);
	exc = (*env)->ExceptionOccurred(env);
	if (exc) {
	    (*env)->DeleteLocalRef(env, exc);
	    return;
	}
#if HAVE_BOTH_SQLITE
	f->is3 = h->is3;
	if (h->is3) {
	    ret = sqlite3_create_function((sqlite3 *) h->sqlite,
					  namestr.result,
					  (int) nargs,
					  SQLITE_UTF8, f,
					  isagg ? NULL : call3_func,
					  isagg ? call3_step : NULL,
					  isagg ? call3_final : NULL);

	} else {
	    if (isagg) {
		ret = sqlite_create_aggregate((sqlite *) h->sqlite,
					      namestr.result,
					      (int) nargs,
					      call_step, call_final, f);
	    } else {
		ret = sqlite_create_function((sqlite *) h->sqlite,
					     namestr.result,
					     (int) nargs,
					     call_func, f);
	    }
	}
#else
#if HAVE_SQLITE2
	if (isagg) {
	    ret = sqlite_create_aggregate((sqlite *) h->sqlite, namestr.result,
					  (int) nargs,
					  call_step, call_final, f);
	} else {
	    ret = sqlite_create_function((sqlite *) h->sqlite, namestr.result,
					 (int) nargs,
					 call_func, f);
	}
#endif
#if HAVE_SQLITE3
	ret = sqlite3_create_function((sqlite3 *) h->sqlite,
				      namestr.result,
				      (int) nargs,
				      SQLITE_UTF8, f,
				      isagg ? NULL : call3_func,
				      isagg ? call3_step : NULL,
				      isagg ? call3_final : NULL);
#endif
#endif
	transfree(&namestr);
	if (ret != SQLITE_OK) {
	    throwex(env, "error creating function/aggregate");
	}
	return;
    }
    throwclosed(env);
}

JNIEXPORT void JNICALL
Java_SQLite_Database_create_1aggregate(JNIEnv *env, jobject obj,
				       jstring name, jint nargs, jobject fi)
{
    mkfunc_common(env, 1, obj, name, nargs, fi);
}

JNIEXPORT void JNICALL
Java_SQLite_Database_create_1function(JNIEnv *env, jobject obj,
				      jstring name, jint nargs, jobject fi)
{
    mkfunc_common(env, 0, obj, name, nargs, fi);
}

JNIEXPORT void JNICALL
Java_SQLite_Database_function_1type(JNIEnv *env, jobject obj,
				    jstring name, jint type)
{
    handle *h = gethandle(env, obj);

    if (h && h->sqlite) {
#if HAVE_BOTH_SQLITE
	if (h->is3) {
	    return;
	}
#endif
#if HAVE_SQLITE2
#if HAVE_SQLITE_FUNCTION_TYPE
	{
	    int ret;
	    transstr namestr;
	    jthrowable exc;

	    trans2iso(env, h->haveutf, h->enc, name, &namestr);
	    exc = (*env)->ExceptionOccurred(env);
	    if (exc) {
		(*env)->DeleteLocalRef(env, exc);
		return;
	    }
	    ret = sqlite_function_type(h->sqlite, namestr.result, (int) type);
	    transfree(&namestr);
	    if (ret != SQLITE_OK) {
		throwex(env, sqlite_error_string(ret));
	    }
	}
#endif
#endif
	return;
    }
    throwclosed(env);
}

JNIEXPORT jint JNICALL
Java_SQLite_FunctionContext_count(JNIEnv *env, jobject obj)
{
    hfunc *f = getfunc(env, obj);
    jint r = 0;

    if (f && f->sf) {
#if HAVE_SQLITE_BOTH
	if (f->is3) {
	    r = (jint) sqlite3_aggregate_count((sqlite3_context *) f->sf);
	} else {
	    r = (jint) sqlite_aggregate_count((sqlite_func *) f->sf);
	}
#else
#if HAVE_SQLITE2
	r = (jint) sqlite_aggregate_count((sqlite_func *) f->sf);
#endif
#if HAVE_SQLITE3
	r = (jint) sqlite3_aggregate_count((sqlite3_context *) f->sf);
#endif
#endif
    }
    return r;
}

JNIEXPORT void JNICALL
Java_SQLite_FunctionContext_set_1error(JNIEnv *env, jobject obj, jstring err)
{
    hfunc *f = getfunc(env, obj);

    if (f && f->sf) {
	transstr errstr;
	jthrowable exc;

	trans2iso(env, f->h->haveutf, f->h->enc, err, &errstr);
	exc = (*env)->ExceptionOccurred(env);
	if (exc) {
	    (*env)->DeleteLocalRef(env, exc);
	    return;
	}
#if HAVE_BOTH_SQLITE
	if (f->is3) {
	    sqlite3_result_error((sqlite3_context *) f->sf,
				 errstr.result, -1);
	} else {
	    sqlite_set_result_error((sqlite_func *) f->sf,
				    errstr.result, -1);
	}
#else
#if HAVE_SQLITE2
	sqlite_set_result_error((sqlite_func *) f->sf, errstr.result, -1);
#endif
#if HAVE_SQLITE3
	sqlite3_result_error((sqlite3_context *) f->sf, errstr.result, -1);
#endif
#endif
	transfree(&errstr);
    }
}

JNIEXPORT void JNICALL
Java_SQLite_FunctionContext_set_1result__D(JNIEnv *env, jobject obj, jdouble d)
{
    hfunc *f = getfunc(env, obj);

    if (f && f->sf) {
#if HAVE_BOTH_SQLITE
	if (f->is3) {
	    sqlite3_result_double((sqlite3_context *) f->sf, (double) d);
	} else {
	    sqlite_set_result_double((sqlite_func *) f->sf, (double) d);
	}
#else
#if HAVE_SQLITE2
	sqlite_set_result_double((sqlite_func *) f->sf, (double) d);
#endif
#if HAVE_SQLITE3
	sqlite3_result_double((sqlite3_context *) f->sf, (double) d);
#endif
#endif
    }
}

JNIEXPORT void JNICALL
Java_SQLite_FunctionContext_set_1result__I(JNIEnv *env, jobject obj, jint i)
{
    hfunc *f = getfunc(env, obj);

    if (f && f->sf) {
#if HAVE_BOTH_SQLITE
	if (f->is3) {
	    sqlite3_result_int((sqlite3_context *) f->sf, (int) i);
	} else {
	    sqlite_set_result_int((sqlite_func *) f->sf, (int) i);
	}
#else
#if HAVE_SQLITE2
	sqlite_set_result_int((sqlite_func *) f->sf, (int) i);
#endif
#if HAVE_SQLITE3
	sqlite3_result_int((sqlite3_context *) f->sf, (int) i);
#endif
#endif
    }
}

JNIEXPORT void JNICALL
Java_SQLite_FunctionContext_set_1result__Ljava_lang_String_2(JNIEnv *env,
							     jobject obj,
							     jstring ret)
{
    hfunc *f = getfunc(env, obj);

    if (f && f->sf) {
	transstr retstr;
	jthrowable exc;

	trans2iso(env, f->h->haveutf, f->h->enc, ret, &retstr);
	exc = (*env)->ExceptionOccurred(env);
	if (exc) {
	    (*env)->DeleteLocalRef(env, exc);
	    return;
	}
#if HAVE_BOTH_SQLITE
	if (f->is3) {
	    sqlite3_result_text((sqlite3_context *) f->sf,
				retstr.result, -1, SQLITE_TRANSIENT);
	} else {
	    sqlite_set_result_string((sqlite_func *) f->sf,
				     retstr.result, -1);
	}
#else
#if HAVE_SQLITE2
	sqlite_set_result_string((sqlite_func *) f->sf, retstr.result, -1);
#endif
#if HAVE_SQLITE3
	sqlite3_result_text((sqlite3_context *) f->sf, retstr.result, -1,
			    SQLITE_TRANSIENT);
#endif
#endif
	transfree(&retstr);
    }
}

JNIEXPORT jstring JNICALL
Java_SQLite_Database_error_1string(JNIEnv *env, jclass c, jint err)
{
#if HAVE_SQLITE2
    return (*env)->NewStringUTF(env, sqlite_error_string((int) err));
#else
    return (*env)->NewStringUTF(env, "unkown error");
#endif
}

JNIEXPORT void JNICALL
Java_SQLite_Database_set_1encoding(JNIEnv *env, jobject obj, jstring enc)
{
    handle *h = gethandle(env, obj);

    if (h && !h->haveutf) {
#if HAVE_BOTH_SQLITE
	if (!h->is3) {
	    delglobrefp(env, &h->enc);
	    h->enc = enc;
	    globrefset(env, enc, &h->enc);
	}
#else
#if HAVE_SQLITE2
	delglobrefp(env, &h->enc);
	h->enc = enc;
	globrefset(env, enc, &h->enc);
#endif
#endif
    }
}

#if HAVE_SQLITE_SET_AUTHORIZER
static int
doauth(void *arg, int what, const char *arg1, const char *arg2,
       const char *arg3, const char *arg4)
{
    handle *h = (handle *) arg;
    JNIEnv *env = h->env;

    if (env && h->ai) {
	jthrowable exc;
	jclass cls = (*env)->GetObjectClass(env, h->ai);
	jmethodID mid;
	jint i = what;

	mid = (*env)->GetMethodID(env, cls, "authorize",
				  "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I");
	if (mid) {
	    jstring s1 = 0, s2 = 0, s3 = 0, s4 = 0;
	    transstr tr;

	    if (arg1) {
		trans2utf(env, h->haveutf, h->enc, arg1, &tr);
		s1 = tr.jstr;
	    }
	    exc = (*env)->ExceptionOccurred(env);
	    if (exc) {
		(*env)->DeleteLocalRef(env, exc);
		return SQLITE_DENY;
	    }
	    if (arg2) {
		trans2utf(env, h->haveutf, h->enc, arg2, &tr);
		s2 = tr.jstr;
	    }
	    if (arg3) {
		trans2utf(env, h->haveutf, h->enc, arg3, &tr);
		s3 = tr.jstr;
	    }
	    if (arg4) {
		trans2utf(env, h->haveutf, h->enc, arg4, &tr);
		s4 = tr.jstr;
	    }
	    exc = (*env)->ExceptionOccurred(env);
	    if (exc) {
		(*env)->DeleteLocalRef(env, exc);
		return SQLITE_DENY;
	    }
	    i = (*env)->CallIntMethod(env, h->ai, mid, i, s1, s2, s3, s4);
	    exc = (*env)->ExceptionOccurred(env);
	    if (exc) {
		(*env)->DeleteLocalRef(env, exc);
		return SQLITE_DENY;
	    }
	    (*env)->DeleteLocalRef(env, s4);
	    (*env)->DeleteLocalRef(env, s3);
	    (*env)->DeleteLocalRef(env, s2);
	    (*env)->DeleteLocalRef(env, s1);
	    if (i != SQLITE_OK && i != SQLITE_IGNORE) {
		i = SQLITE_DENY;
	    }
	    return (int) i;
	}
    }
    return SQLITE_DENY;
}
#endif

JNIEXPORT void JNICALL
Java_SQLite_Database_set_1authorizer(JNIEnv *env, jobject obj, jobject auth)
{
    handle *h = gethandle(env, obj);

    if (h && h->sqlite) {
	delglobrefp(env, &h->ai);
	globrefset(env, auth, &h->ai);
#if HAVE_SQLITE_SET_AUTHORIZER
	h->env = env;
#if HAVE_BOTH_SQLITE
	if (h->is3) {
	    sqlite3_set_authorizer((sqlite3 *) h->sqlite,
				   h->ai ? doauth : 0, h);
	} else {
	    sqlite_set_authorizer((sqlite *) h->sqlite,
				  h->ai ? doauth : 0, h);
	}
#else
#if HAVE_SQLITE2
	sqlite_set_authorizer((sqlite *) h->sqlite, h->ai ? doauth : 0, h);
#endif
#if HAVE_SQLITE3
	sqlite3_set_authorizer((sqlite3 *) h->sqlite, h->ai ? doauth : 0, h);
#endif
#endif
#endif
	return;
    }
    throwclosed(env);
}

#if HAVE_SQLITE_TRACE
static void
dotrace(void *arg, const char *msg)
{
    handle *h = (handle *) arg;
    JNIEnv *env = h->env;

    if (env && h->tr && msg) {
	jthrowable exc;
	jclass cls = (*env)->GetObjectClass(env, h->tr);
	jmethodID mid;

	mid = (*env)->GetMethodID(env, cls, "trace", "(Ljava/lang/String;)V");
	if (mid) {
	    transstr tr;

	    trans2utf(env, h->haveutf, h->enc, msg, &tr);
	    exc = (*env)->ExceptionOccurred(env);
	    if (exc) {
		(*env)->DeleteLocalRef(env, exc);
		(*env)->ExceptionClear(env);
		return;
	    }
	    (*env)->CallVoidMethod(env, h->tr, mid, tr.jstr);
	    (*env)->ExceptionClear(env);
	    (*env)->DeleteLocalRef(env, tr.jstr);
	    return;
	}
    }
    return;
}
#endif

JNIEXPORT void JNICALL
Java_SQLite_Database_trace(JNIEnv *env, jobject obj, jobject tr)
{
    handle *h = gethandle(env, obj);

    if (h && h->sqlite) {
	delglobrefp(env, &h->tr);
	globrefset(env, tr, &h->tr);
#if HAVE_BOTH_SQLITE
	if (h->is3) {
	    sqlite3_trace((sqlite3 *) h->sqlite, h->tr ? dotrace : 0, h);
	} else {
#if HAVE_SQLITE_TRACE
	    sqlite_trace((sqlite *) h->sqlite, h->tr ? dotrace : 0, h);
#endif
	}
#else
#if HAVE_SQLITE2
#if HAVE_SQLITE_TRACE
	sqlite_trace((sqlite *) h->sqlite, h->tr ? dotrace : 0, h);
#endif
#endif
#if HAVE_SQLITE3
	sqlite3_trace((sqlite3 *) h->sqlite, h->tr ? dotrace : 0, h);
#endif
#endif
	return;
    }
    throwclosed(env);
}

#if HAVE_SQLITE_COMPILE
static void
dovmfinal(JNIEnv *env, jobject obj, int final)
{
    hvm *v = gethvm(env, obj);

    if (v) {
	if (v->h) {
	    handle *h = v->h;
	    hvm *vv, **vvp;

	    vvp = &h->vms;
	    vv = *vvp;
	    while (vv) {
		if (vv == v) {
		    *vvp = vv->next;
		    break;
		}
		vvp = &vv->next;
		vv = *vvp;
	    }
	}
	if (v->vm) {
#if HAVE_BOTH_SQLITE
	    if (v->is3) {
		sqlite3_finalize((sqlite3_stmt *) v->vm);
	    } else {
		sqlite_finalize((sqlite_vm *) v->vm, 0);
	    }
#else
#if HAVE_SQLITE2
	    sqlite_finalize((sqlite_vm *) v->vm, 0);
#endif
#if HAVE_SQLITE3
	    sqlite3_finalize((sqlite3_stmt *) v->vm);
#endif
#endif
	    v->vm = 0;
	}
	free(v);
	(*env)->SetLongField(env, obj, F_SQLite_Vm_handle, 0);
	return;
    }
    if (!final) {
	throwex(env, "vm already closed");
    }
}
#endif

JNIEXPORT void JNICALL
Java_SQLite_Vm_stop(JNIEnv *env, jobject obj)
{
#if HAVE_SQLITE_COMPILE
    dovmfinal(env, obj, 0);
#else
    throwex(env, "unsupported");
#endif
}

JNIEXPORT void JNICALL
Java_SQLite_Vm_finalize(JNIEnv *env, jobject obj)
{
#if HAVE_SQLITE_COMPILE
    dovmfinal(env, obj, 1);
#endif
}

JNIEXPORT jboolean JNICALL
Java_SQLite_Vm_step(JNIEnv *env, jobject obj, jobject cb)
{
#if HAVE_SQLITE_COMPILE
    hvm *v = gethvm(env, obj);

    if (v && v->vm && v->h) {
	jthrowable exc;
	int ret, ncol = 0;
#if HAVE_SQLITE3
	freemem *freeproc = 0;
#endif
	const char **data = 0, **cols = 0;

	v->h->env = env;
#if HAVE_BOTH_SQLITE
	if (v->is3) {
	    ret = sqlite3_step((sqlite3_stmt *) v->vm);
	    if (ret == SQLITE_ROW) {
		ncol = sqlite3_column_count((sqlite3_stmt *) v->vm);
		if (ncol > 0) {
		    data = calloc(sizeof (char *), ncol * 2 + 2);
		    if (data) {
			cols = data + ncol + 1;
			freeproc = free;
		    } else {
			ret = SQLITE_NOMEM;
		    }
		}
		if (ret != SQLITE_NOMEM) {
		    int i;

		    for (i = 0; i < ncol; i++) {
			cols[i] =
			    sqlite3_column_name((sqlite3_stmt *) v->vm, i);
			data[i] =
			    sqlite3_column_text((sqlite3_stmt *) v->vm, i);
		    }
		}
	    }
	} else {
	    ret = sqlite_step((sqlite_vm *) v->vm, &ncol, &data, &cols);
	}
#else
#if HAVE_SQLITE2
	ret = sqlite_step((sqlite_vm *) v->vm, &ncol, &data, &cols);
#endif
#if HAVE_SQLITE3
	ret = sqlite3_step((sqlite3_stmt *) v->vm);
	if (ret == SQLITE_ROW) {
	    ncol = sqlite3_column_count((sqlite3_stmt *) v->vm);
	    if (ncol > 0) {
		data = calloc(sizeof (char *), ncol * 2 + 2);
		if (data) {
		    cols = data + ncol + 1;
		    freeproc = free;
		} else {
		    ret = SQLITE_NOMEM;
		}
	    }
	    if (ret != SQLITE_NOMEM) {
		int i;

		for (i = 0; i < ncol; i++) {
		    cols[i] = sqlite3_column_name((sqlite3_stmt *) v->vm, i);
		    data[i] = sqlite3_column_text((sqlite3_stmt *) v->vm, i);
		}
	    }
	}
#endif
#endif
	if (ret == SQLITE_ROW) {
	    v->hh.cb = cb;
	    v->hh.env = env;
#if HAVE_BOTH_SQLITE
	    if (v->is3) {
		v->hh.stmt = (sqlite3_stmt *) v->vm;
	    }
#else
#if HAVE_SQLITE3
	    v->hh.stmt = (sqlite3_stmt *) v->vm;
#endif
#endif
	    callback((void *) &v->hh, ncol, (char **) data, (char **) cols);
#if HAVE_SQLITE3
	    if (data && freeproc) {
		freeproc(data);
	    }
#endif
	    exc = (*env)->ExceptionOccurred(env);
	    if (exc) {
		(*env)->DeleteLocalRef(env, exc);
		goto dofin;
	    }
	    return JNI_TRUE;
	} else if (ret == SQLITE_DONE) {
dofin:
#if HAVE_BOTH_SQLITE
	    if (v->is3) {
		sqlite3_finalize((sqlite3_stmt *) v->vm);
	    } else {
		sqlite_finalize((sqlite_vm *) v->vm, 0);
	    }
#else
#if HAVE_SQLITE2
	    sqlite_finalize((sqlite_vm *) v->vm, 0);
#endif
#if HAVE_SQLITE3
	    sqlite3_finalize((sqlite3_stmt *) v->vm);
#endif
#endif
	    v->vm = 0;
	    return JNI_FALSE;
	}
#if HAVE_BOTH_SQLITE
	if (v->is3) {
	    sqlite3_finalize((sqlite3_stmt *) v->vm);
	} else {
	    sqlite_finalize((sqlite_vm *) v->vm, 0);
	}
#else
#if HAVE_SQLITE2
	sqlite_finalize((sqlite_vm *) v->vm, 0);
#endif
#if HAVE_SQLITE3
	sqlite3_finalize((sqlite3_stmt *) v->vm);
#endif
#endif
	setvmerr(env, obj, ret);
	v->vm = 0;
	throwex(env, "error in step");
	return JNI_FALSE;
    }
    throwex(env, "vm already closed");
#else
    throwex(env, "unsupported");
#endif
    return JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_SQLite_Vm_compile(JNIEnv *env, jobject obj)
{
#if HAVE_SQLITE_COMPILE
    hvm *v = gethvm(env, obj);
    void *svm = 0;
    char *err = 0;
    const char *tail;
    int ret;

    if (v && v->vm) {
#if HAVE_BOTH_SQLITE
	if (v->is3) {
	    sqlite3_finalize((sqlite3_stmt *) v->vm);
	} else {
	    sqlite_finalize((sqlite_vm *) v->vm, 0);
	}
#else
#if HAVE_SQLITE2
	sqlite_finalize((sqlite_vm *) v->vm, 0);
#endif
#if HAVE_SQLITE3
	sqlite3_finalize((sqlite3_stmt *) v->vm);
#endif
#endif
	v->vm = 0;
    }
    if (v && v->h && v->h->sqlite) {
	if (!v->tail) {
	    return JNI_FALSE;
	}
	v->h->env = env;
#if HAVE_BOTH_SQLITE
	if (v->is3) {
	    ret = sqlite3_prepare((sqlite3 *) v->h->sqlite, v->tail, -1,
				  (sqlite3_stmt **) &svm, &tail);
	    if (ret != SQLITE_OK) {
		if (svm) {
		    sqlite3_finalize((sqlite3_stmt *) svm);
		}
	    }
	} else {
	    ret = sqlite_compile((sqlite *) v->h->sqlite, v->tail,
				 &tail, (sqlite_vm **) &svm, &err);
	    if (ret != SQLITE_OK) {
		if (svm) {
		    sqlite_finalize((sqlite_vm *) svm, 0);
		}
	    }
	}
#else
#if HAVE_SQLITE2
	ret = sqlite_compile((sqlite *) v->h->sqlite, v->tail,
			     &tail, (sqlite_vm **) &svm, &err);
	if (ret != SQLITE_OK) {
	    if (svm) {
		sqlite_finalize((sqlite_vm *) svm, 0);
	    }
	}
#endif
#if HAVE_SQLITE3
	ret = sqlite3_prepare((sqlite3 *) v->h->sqlite,
			      v->tail, -1, (sqlite3_stmt **) &svm, &tail);
	if (ret != SQLITE_OK) {
	    if (svm) {
		sqlite3_finalize((sqlite3_stmt *) svm);
	    }
	}
#endif
#endif
	if (ret != SQLITE_OK) {
#if HAVE_SQLITE2
	    if (err) {
		sqlite_freemem(err);
	    }
#endif
	    setvmerr(env, obj, ret);
	    v->tail = 0;
	    throwex(env, err ? err : "error in compile/prepare");
	    return JNI_FALSE;
	}
#if HAVE_SQLITE2
	if (err) {
	    sqlite_freemem(err);
	}
#endif
	if (!svm) {
	    v->tail = 0;
	    return JNI_FALSE;
	}
	v->vm = svm;
	v->tail = (char *) tail;
	v->hh.row1 = 1;
	return JNI_TRUE;
    }
    throwex(env, "vm already closed");
#else
    throwex(env, "unsupported");
#endif
    return JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_SQLite_Database_vm_1compile(JNIEnv *env, jobject obj, jstring sql,
				 jobject vm)
{
#if HAVE_SQLITE_COMPILE
    handle *h = gethandle(env, obj);
    void *svm = 0;
    hvm *v;
    char *err = 0;
    const char *tail;
    transstr tr;
    jvalue vv;
    int ret;
    jthrowable exc;

    if (!h) {
	throwclosed(env);
	return;
    }
    if (!vm) {
	throwex(env, "null vm");
	return;
    }
    if (!sql) {
	throwex(env, "null sql");
	return;
    }
    trans2iso(env, h->haveutf, h->enc, sql, &tr);
    exc = (*env)->ExceptionOccurred(env);
    if (exc) {
	(*env)->DeleteLocalRef(env, exc);
	return;
    }
    h->env = env;
#if HAVE_BOTH_SQLITE
    if (h->is3) {
	ret = sqlite3_prepare((sqlite3 *) h->sqlite, tr.result, -1,
			      (sqlite3_stmt **) &svm, &tail);
	if (ret != SQLITE_OK) {
	    if (svm) {
		sqlite3_finalize((sqlite3_stmt *) svm);
	    }
	}
    } else {
	ret = sqlite_compile((sqlite *) h->sqlite, tr.result, &tail,
			     (sqlite_vm **) &svm, &err);
	if (ret != SQLITE_OK) {
	    if (svm) {
		sqlite_finalize((sqlite_vm *) svm, 0);
	    }
	}
    }
#else
#if HAVE_SQLITE2
    ret = sqlite_compile((sqlite *) h->sqlite, tr.result, &tail,
			 (sqlite_vm **) &svm, &err);
    if (ret != SQLITE_OK) {
	if (svm) {
	    sqlite_finalize((sqlite_vm *) svm, 0);
	}
    }
#endif
#if HAVE_SQLITE3
    ret = sqlite3_prepare((sqlite3 *) h->sqlite, tr.result, -1,
			  (sqlite3_stmt **) &svm, &tail);
    if (ret != SQLITE_OK) {
	if (svm) {
	    sqlite3_finalize((sqlite3_stmt *) svm);
	}
    }
#endif
#endif
    if (ret != SQLITE_OK) {
	transfree(&tr);
#if HAVE_SQLITE2
	if (err) {
	    sqlite_freemem(err);
	}
#endif
	setvmerr(env, vm, ret);
	throwex(env, err ? err : "error in prepare/compile");
	return;
    }
#if HAVE_SQLITE2
    if (err) {
	sqlite_freemem(err);
    }
#endif
    if (!svm) {
	transfree(&tr);
	return;
    }
    v = malloc(sizeof (hvm) + strlen(tail) + 1);
    if (!v) {
	transfree(&tr);
#if HAVE_BOTH_SQLITE
	if (h->is3) {
	    sqlite3_finalize((sqlite3_stmt *) svm);
	} else {
	    sqlite_finalize((sqlite_vm *) svm, 0);
	}
#else
#if HAVE_SQLITE2
	sqlite_finalize((sqlite_vm *) svm, 0);
#endif
#if HAVE_SQLITE3
	sqlite3_finalize((sqlite3_stmt *) svm);
#endif
#endif
	throwoom(env, "unable to get SQLite handle");
	return;
    }
    v->next = h->vms;
    h->vms = v;
    v->vm = svm;
    v->h = h;
    v->tail = (char *) (v + 1);
#if HAVE_BOTH_SQLITE
    v->is3 = v->hh.is3 = h->is3;
#endif
    strcpy(v->tail, tail);
    v->hh.sqlite = 0;
    v->hh.haveutf = h->haveutf;
    v->hh.ver = h->ver;
    v->hh.bh = v->hh.cb = v->hh.ai = v->hh.tr = v->hh.ph = 0;
    v->hh.row1 = 1;
    v->hh.enc = h->enc;
    v->hh.funcs = 0;
    v->hh.vms = 0;
    v->hh.env = 0;
    vv.j = 0;
    vv.l = (jobject) v;
    (*env)->SetLongField(env, vm, F_SQLite_Vm_handle, vv.j);
#else
    throwex(env, "unsupported");
#endif
}

JNIEXPORT void JNICALL
Java_SQLite_Database_vm_1compile_1args(JNIEnv *env,
				       jobject obj, jstring sql,
				       jobject vm, jobjectArray args)
{
#if HAVE_SQLITE_COMPILE
#if HAVE_SQLITE3
    handle *h = gethandle(env, obj);
#endif

#if HAVE_BOTH_SQLITE
    if (h && !h->is3) {
	throwex(env, "unsupported");
	return;
    }
#else
#if HAVE_SQLITE2
    throwex(env, "unsupported");
#endif
#endif
#if HAVE_SQLITE3 
    if (!h || !h->sqlite) {
	throwclosed(env);
	return;
    }
    if (!vm) {
	throwex(env, "null vm");
	return;
    }
    if (!sql) {
	throwex(env, "null sql");
	return;
    } else {
	void *svm = 0;
	hvm *v;
	jvalue vv;
	jthrowable exc;
	jboolean b;
	int rc = SQLITE_ERROR, nargs, i;
	char *p;
	const char *str = (*env)->GetStringUTFChars(env, sql, &b);
	const char *tail;
	transstr sqlstr;
	struct args {
	    char *arg;
	    jobject obj;
	    transstr trans;
	} *argv = 0;
	char **cargv = 0;

	p = (char *) str;
	nargs = 0;
	while (*p) {
	    if (*p == '%') {
		++p;
		if (*p == 'q' || *p == 'Q') {
		    nargs++;
		} else if (*p != '%') {
		    (*env)->ReleaseStringUTFChars(env, sql, str);
		    throwex(env, "bad % specification in query");
		    return;
		}
	    }
	    ++p;
	}
	if (nargs) {
	    cargv = malloc((sizeof (*argv) + sizeof (char *)) * nargs);

	    if (!cargv) {
		(*env)->ReleaseStringUTFChars(env, sql, str);
		throwoom(env, "unable to allocate arg vector");
		return;
	    }
	    argv = (struct args *) (cargv + nargs);
	    for (i = 0; i < nargs; i++) {
		cargv[i] = 0;
		argv[i].arg = 0;
		argv[i].obj = 0;
		argv[i].trans.result = argv[i].trans.tofree = 0;
	    }
	}
	exc = 0;
	for (i = 0; i < nargs; i++) {
	    jobject so = (*env)->GetObjectArrayElement(env, args, i);

	    exc = (*env)->ExceptionOccurred(env);
	    if (exc) {
		(*env)->DeleteLocalRef(env, exc);
		break;
	    }
	    if (so) {
		argv[i].obj = so;
		argv[i].arg = cargv[i] =
		    trans2iso(env, 1, 0, argv[i].obj, &argv[i].trans);
	    }
	}
	if (exc) {
	    for (i = 0; i < nargs; i++) {
		if (argv[i].obj) {
		    transfree(&argv[i].trans);
		}
	    }
	    freep((char **) &cargv);
	    return;
	}
	h->row1 = 1;
	trans2iso(env, 1, 0, sql, &sqlstr);
	exc = (*env)->ExceptionOccurred(env);
	if (!exc) {
	    char *s = sqlite3_vmprintf(sqlstr.result, (char *) cargv);

	    if (!s) {
		rc = SQLITE_NOMEM;
	    } else {
		rc = sqlite3_prepare((sqlite3 *) h->sqlite, s, -1,
				      (sqlite3_stmt **) &svm, &tail);
		if (rc != SQLITE_OK) {
		    if (svm) {
			sqlite3_finalize((sqlite3_stmt *) svm);
		    }
		}
	    }
	    if (rc != SQLITE_OK) {
		sqlite3_free(s);
		for (i = 0; i < nargs; i++) {
		    if (argv[i].obj) {
			transfree(&argv[i].trans);
		    }
		}
		freep((char **) &cargv);
		transfree(&sqlstr);
		setvmerr(env, vm, rc);
		throwex(env, "error in prepare");
		return;
	    }
	    v = malloc(sizeof (hvm) + strlen(tail) + 1);
	    if (!v) {
		sqlite3_free(s);
		for (i = 0; i < nargs; i++) {
		    if (argv[i].obj) {
			transfree(&argv[i].trans);
		    }
		}
		freep((char **) &cargv);
		transfree(&sqlstr);
		sqlite3_finalize((sqlite3_stmt *) svm);
		setvmerr(env, vm, SQLITE_NOMEM);
		throwoom(env, "unable to get SQLite handle");
		return;
	    }
	    v->next = h->vms;
	    h->vms = v;
	    v->vm = svm;
	    v->h = h;
	    v->tail = (char *) (v + 1);
#if HAVE_BOTH_SQLITE
	    v->is3 = v->hh.is3 = h->is3;
#endif
	    strcpy(v->tail, tail);
	    sqlite3_free(s);
	    v->hh.sqlite = 0;
	    v->hh.haveutf = h->haveutf;
	    v->hh.ver = h->ver;
	    v->hh.bh = v->hh.cb = v->hh.ai = v->hh.tr = v->hh.ph = 0;
	    v->hh.row1 = 1;
	    v->hh.enc = h->enc;
	    v->hh.funcs = 0;
	    v->hh.vms = 0;
	    v->hh.env = 0;
	    vv.j = 0;
	    vv.l = (jobject) v;
	    (*env)->SetLongField(env, vm, F_SQLite_Vm_handle, vv.j);
	}
	for (i = 0; i < nargs; i++) {
	    if (argv[i].obj) {
		transfree(&argv[i].trans);
	    }
	}
	freep((char **) &cargv);
	transfree(&sqlstr);
	if (exc) {
	    (*env)->DeleteLocalRef(env, exc);
	}
    }
#endif
#else
    throwex(env, "unsupported");
#endif
}

JNIEXPORT void JNICALL
Java_SQLite_FunctionContext_internal_1init(JNIEnv *env, jclass cls)
{
    F_SQLite_FunctionContext_handle =
	(*env)->GetFieldID(env, cls, "handle", "J");
}

JNIEXPORT void JNICALL
Java_SQLite_Database_progress_1handler(JNIEnv *env, jobject obj, jint n,
				       jobject ph)
{
    handle *h = gethandle(env, obj);

    if (h && h->sqlite) {
	/* CHECK THIS */
#if HAVE_SQLITE_PROGRESS_HANDLER
	delglobrefp(env, &h->ph);
#if HAVE_BOTH_SQLITE
	if (h->is3) {
	    if (ph) {
		globrefset(env, ph, &h->ph);
		sqlite3_progress_handler((sqlite3 *) h->sqlite,
					 n, progresshandler, h);
	    } else {
		sqlite3_progress_handler((sqlite3 *) h->sqlite,
					 0, 0, 0);
	    }
	} else {
	    if (ph) {
		globrefset(env, ph, &h->ph);
		sqlite_progress_handler((sqlite *) h->sqlite,
					n, progresshandler, h);
	    } else {
		sqlite_progress_handler((sqlite *) h->sqlite,
					0, 0, 0);
	    }
	}
#else
#if HAVE_SQLITE2
	if (ph) {
	    globrefset(env, ph, &h->ph);
	    sqlite_progress_handler((sqlite *) h->sqlite,
				    n, progresshandler, h);
	} else {
	    sqlite_progress_handler((sqlite *) h->sqlite,
				    0, 0, 0);
	}
#endif
#if HAVE_SQLITE3
	if (ph) {
	    globrefset(env, ph, &h->ph);
	    sqlite3_progress_handler((sqlite3 *) h->sqlite,
				     n, progresshandler, h);
	} else {
	    sqlite3_progress_handler((sqlite3 *) h->sqlite,
				     0, 0, 0);
	}
#endif
#endif
	return;
#else
	throwex(env, "unsupported");
	return;
#endif
    }
    throwclosed(env);
}

JNIEXPORT jboolean JNICALL
Java_SQLite_Database_is3(JNIEnv *env, jobject obj)
{
#if HAVE_BOTH_SQLITE
    handle *h = gethandle(env, obj);

    if (h) {
	return h->is3 ? JNI_TRUE : JNI_FALSE;
    }
    return JNI_FALSE;
#else
#if HAVE_SQLITE2
    return JNI_FALSE;
#endif
#if HAVE_SQLITE3
    return JNI_TRUE;
#endif
#endif
}

JNIEXPORT void JNICALL
Java_SQLite_Vm_internal_1init(JNIEnv *env, jclass cls)
{
    F_SQLite_Vm_handle =
	(*env)->GetFieldID(env, cls, "handle", "J");
    F_SQLite_Vm_error_code =
	(*env)->GetFieldID(env, cls, "error_code", "I");
}

JNIEXPORT void JNICALL
Java_SQLite_Database_internal_1init(JNIEnv *env, jclass cls)
{
#ifndef JNI_VERSION_1_2
    jclass jls = (*env)->FindClass(env, "java/lang/String");

    C_java_lang_String = (*env)->NewGlobalRef(env, jls);
#endif
    F_SQLite_Database_handle =
	(*env)->GetFieldID(env, cls, "handle", "J");
    F_SQLite_Database_error_code =
	(*env)->GetFieldID(env, cls, "error_code", "I");
    M_java_lang_String_getBytes =
	(*env)->GetMethodID(env, C_java_lang_String, "getBytes", "()[B");
    M_java_lang_String_getBytes2 =
	(*env)->GetMethodID(env, C_java_lang_String, "getBytes",
			    "(Ljava/lang/String;)[B");
    M_java_lang_String_initBytes =
	(*env)->GetMethodID(env, C_java_lang_String, "<init>", "([B)V");
    M_java_lang_String_initBytes2 =
	(*env)->GetMethodID(env, C_java_lang_String, "<init>",
			    "([BLjava/lang/String;)V");
}

#ifdef JNI_VERSION_1_2
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved)
{
    JNIEnv *env;
    jclass cls;

#ifndef _WIN32
#if HAVE_SQLITE2
    if (strcmp(sqlite_libencoding(), "UTF-8") != 0) {
	fprintf(stderr, "WARNING: using non-UTF SQLite2 engine\n");
    }
#endif
#endif
    if ((*vm)->GetEnv(vm, (void **) &env, JNI_VERSION_1_2)) {
	return JNI_ERR;
    }
    cls = (*env)->FindClass(env, "java/lang/String");
    if (!cls) {
	return JNI_ERR;
    }
    C_java_lang_String = (*env)->NewWeakGlobalRef(env, cls);
    return JNI_VERSION_1_2;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved)
{
    JNIEnv *env;

    if ((*vm)->GetEnv(vm, (void **) &env, JNI_VERSION_1_2)) {
	return;
    }
    if (C_java_lang_String) {
	(*env)->DeleteWeakGlobalRef(env, C_java_lang_String);
	C_java_lang_String = 0;
    }
}
#endif
